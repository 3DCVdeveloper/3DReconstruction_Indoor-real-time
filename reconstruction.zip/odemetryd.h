#ifndef ODEMETRY_H
#define ODEMETRY_H

#include <QObject>
#include "astra.h"
//#include "open3d/Open3D.h"
#include "OpenNI.h"
//#include "open3d/core/Dtype.h"
#include <QMutex>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>
#include <eigen3/Eigen/Dense>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/types_c.h>
//#include "opencv2/imgcodecs/legacy/constants_c.h"
//#include <opencv2/imgcodecs/imgcodecs_c.h>

//#include <opencv2/core/core.hpp>
#include "dvo.h"
#include <fstream>
#include <chrono>

#include <pcl/io/pcd_io.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/ndt.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/approximate_voxel_grid.h>
#include <pcl/filters/filter.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/visualization/pcl_visualizer.h>  
#include <pcl/filters/fast_bilateral.h>
#include <pcl/filters/bilateral.h>
#include <pcl/common/common.h>
#include "pclshowstream.h"
#include <pcl/kdtree/flann.h>  
#include <pcl/kdtree/kdtree.h>  
#include <pcl/search/flann_search.h>  
#include <pcl/search/kdtree.h>
#include <pcl/kdtree/kdtree_flann.h>  
#include <pcl/filters/bilateral.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include "cudaICP.h"
#include "cudaFilter.h"
#include <pcl/common/impl/common.hpp>
#include <pcl/common/impl/centroid.hpp>
#include <halconcpp/HalconCpp.h>
#include <halconcpp/HDevThread.h>
#include <halconcpp/HTuple.h>
using namespace HalconCpp;
using namespace openni;
//using namespace open3d;
//using core::Tensor;
//using t::geometry::Image;
//using t::geometry::PointCloud;
//using t::geometry::RGBDImage;
//using t::pipelines::slam;
#include <PS1080.h>
struct Iter_para //Interation paraments
{
    constexpr static int PCountN = 35947;// control count of N
    int Maxiterate;//Maximum iteration count
    double threshold;//threshold for distance Error
    double acceptrate;//accept rate
};
class odemetrytdd : public QObject
{
    Q_OBJECT
public:
    explicit odemetrytdd(QObject *parent = nullptr);

signals:
    void sgnl_manwindowshowpoint(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow);
    void sgnl_initvtk();
    void sgnl_rendervtk();
    void sgnl_updatepointcloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointsupdate);
public slots:
    void slt_sendcolorimg(cv::Mat pcolorsend);
    void slt_senddepthimg(cv::Mat pdepthsend);
    void slt_sendicpcolorimg(RGB888Pixel* pcolorsend);
    void slt_sendicpdepthimg(DepthPixel* pdepthsend);
    void slt_setintrinsic(double fx, double fy, double cx, double cy);
    void slt_stop();
private:
    RGB888Pixel* pcolorsendode;
    DepthPixel*  pdepthsendode;
//    geometry::Image *depthimage;
    uint16_t *imagedata;
    uint8_t *colorimagedata;
//    geometry::Image *input_color;
//    geometry::Image *depthimageref;
    uint16_t *imagedataref;
    uint8_t *colorimagedataref;
//    geometry::Image *input_colorref;
//    open3d::core::SizeVector shape;
    std::vector<uint8_t> colortensor;
    bool colorcoming;
    bool depthcoming;
    uint16_t max_depth;
    uint32_t astra_index;
    uint16_t min_depth;
    void computeodemetry();
    void computepointodemetry();
    QMutex colormutex;
    QMutex depthmutex;
//    Tensor intrinsic_t;
    float voxel_size = 3.f / 512.f;
    float sdf_trunc = 0.04f;
    int block_resolution = 16;
    int block_count = 10000;
    float depth_scale = 1000.f;
    float depth_max = 5.f;
    float depth_diff = 0.07f;
//    Tensor T_frame_to_model;
//    t::pipelines::slam::Model *model;
//     t::pipelines::slam::Frame *raycast_frame;
//     t::pipelines::slam::Frame *input_frame;
//     pipelines::odometry::OdometryOption option;
     Eigen::Matrix4d odo_init  ;
     Eigen::Matrix4d trans_odo ;
//     Eigen::Matrix6d info_odo  ;
     Eigen::Matrix<double,6,6>  info_odo  ;
//     std::shared_ptr<geometry::RGBDImage> source_rgbd_imageref;
//     camera::PinholeCameraIntrinsic pinholeintrinsic;
     Eigen::Matrix3f intrinsiccv;
     std::vector<Eigen::Matrix4f> poses;
     DVO dvo;
     cv::Mat grayRef;
     cv::Mat depthRef;
     Eigen::Matrix4f absPose;
     std::vector<float*> grayRefPyramid; // this will store device pointers
     std::vector<float*> depthRefPyramid; // this will store device pointers
     double runtimeAvg = 0.0;
     Iter_para odemetryiter{ 20, 1e-12, 1.0 };
     void generateOffFile(std::string dataFolder, std::string rgbImage, std::string depthImage, Eigen::Matrix3f intrinsics, std::vector<Eigen::Matrix4f> poses);
     void PCLfilter(pcl::PointCloud<pcl::PointXYZ>::Ptr cloudSrc,
             pcl::PointCloud<pcl::PointXYZ>::Ptr cloudDst);
     void CUDAfileter(pcl::PointCloud<pcl::PointXYZ>::Ptr cloudSrc,
             pcl::PointCloud<pcl::PointXYZ>::Ptr cloudDst, float voxelsize);
     double calculateFitneeScore(pcl::PointCloud<pcl::PointXYZ>::Ptr P,
             pcl::PointCloud<pcl::PointXYZ>::Ptr Q,
             Eigen::Matrix4f transformation_matrix);
             void testPCLICP(pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_in, pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_out,  Iter_para iter);
     void cudaIICP(pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_in,
             pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_out,
             Iter_para iter, Eigen::Matrix4f &transformation_matrix);
     void print4x4Matrix(const Eigen::Matrix4f & matrix);
     void addNormal(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud,pcl::PointCloud<pcl::PointNormal>::Ptr normals,
	       pcl::PointCloud<pcl::PointXYZRGBNormal>::Ptr cloud_with_normals
);
     void cloudviewONEcloudwithoutnormals(pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr cloud_source);
     pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow;
     pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshowref;
     pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointcomputefast;
     pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointcomputefastref;
     pcl::PointCloud<pcl::PointNormal>::Ptr pointcomputefastrefnormal;
     pcl::PointCloud<pcl::PointNormal>::Ptr pointcomputefastnormal;
     pcl::PointCloud<pcl::PointXYZ>::Ptr pointref;
     pcl::PointCloud<pcl::PointXYZ>::Ptr pointcurrent;
     pcl::PointCloud<pcl::PointXYZI>::Ptr pointrefI;
     pcl::PointCloud<pcl::PointXYZI>::Ptr pointcurrentI;
     pcl::PointCloud<pcl::PointXYZ>::Ptr pointmodel;
     pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_after_bilateralFilter;
     pclshowstream *pclstreamor;
     boost::mutex updateModelMutex;
     boost::shared_ptr<pcl::visualization::PCLVisualizer> viewerthread;
     void viewerRunner(boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer);
     boost::shared_ptr<pcl::visualization::PCLVisualizer> simpleVis (pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr cloud);
     HTuple halconReference;
     HTuple halconcurr;
     HTuple pcl2Halcon(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud);
     std::vector<std::pair<std::vector<float>, Eigen::Matrix4f>>  halconreg(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud);
};

#endif // ODEMETRY_H
