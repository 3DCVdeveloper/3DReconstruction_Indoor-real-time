#include "vtkshowrgb.h"

vtkShowRGB::vtkShowRGB(QObject *parent) : QObject(parent)
{

}
void vtkShowRGB::slt_init()
{
	/*Rendererrgb = vtkSmartPointer<vtkRenderer>::New();
	anActorrgbpointclouds = vtkSmartPointer<vtkActor>::New();
	lutpointclouds = vtkSmartPointer<vtkLookupTable>::New();
	anActorrgbtrack = vtkSmartPointer<vtkActor>::New();
	pointsrgb = vtkSmartPointer<vtkPoints>::New();
	pointsScalars = vtkSmartPointer<vtkFloatArray>::New();
	pointsGrid = vtkSmartPointer<vtkUnstructuredGrid>::New();
	pointcloudsMapper = vtkSmartPointer<vtkDataSetMapper>::New();
	trackMapper = vtkSmartPointer<vtkDataSetMapper>::New();
	polyVertex = vtkSmartPointer<vtkPolyVertex>::New();
	rgbrenderWindow = vtkSmartPointer<vtkRenderWindow>::New();
	Rendererrgb->AddActor(anActorrgbpointclouds);
	Rendererrgb->ResetCamera();
//    Rendererrgb->SetBackground(1.0,1.0,1.0);
//	Rendererrgb->DrawOn();
	rgbrenderWindow->AddRenderer(Rendererrgb);*/
//init
    m_actor = vtkSmartPointer<vtkActor>::New();
//    m_actor->GetProperty()->SetColor(0, 255, 0);
	m_renderer = vtkSmartPointer<vtkRenderer>::New();
    m_renderer->SetBackground(1.0,1.0,1.0);
	m_renderer->AddActor(m_actor);
	renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
	renderWindow->AddRenderer(m_renderer);
	renderWindow->SetSize(640, 480);
    renderWindow->SetPosition(700,800);
	renderWindow->SetWindowName("vtkshow");
	interactor = vtkSmartPointer<vtkRenderWindowInteractor>::New();
	interactor->SetRenderWindow(renderWindow);
//    interactor->Start();
}
void vtkShowRGB::slt_updatedata(pcl::PointCloud<pcl::PointXYZRGB>::Ptr playpointrgb)
{

    /*pcl::PointCloud<pcl::PointXYZRGB>::Ptr curcloudsourcedown = pcl::PointCloud<pcl::PointXYZRGB>::Ptr(new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::copyPointCloud(*playpointrgb, *curcloudsourcedown);
    int number = curcloudsourcedown->size();
	pointsrgb->SetNumberOfPoints(number);
	lutpointclouds->SetNumberOfTableValues(number);
	int i = 0;
    for (auto item : curcloudsourcedown->points)
	{
		pointsrgb->InsertPoint(i, item.x, item.y, item.z);
		lutpointclouds->SetTableValue(i, item.r / 255.0, item.g / 255.0, item.b / 255.0, 1);
		i++;
	}
	polyVertex->GetPointIds()->SetNumberOfIds(number);
	pointsScalars->SetNumberOfTuples(number);
	for (i = 0; i < number; i++)
	{
		polyVertex->GetPointIds()->SetId(i, i);
		pointsScalars->InsertValue(i, i);
	}
	pointsGrid->Allocate(1, 1);
	pointsGrid->SetPoints(pointsrgb);
	pointsGrid->GetPointData()->SetScalars(pointsScalars);
	pointsGrid->InsertNextCell(polyVertex->GetCellType(), polyVertex->GetPointIds()); 

	//trackMapper->SetInputData(pointsGrid);

	pointcloudsMapper->SetInputData(pointsGrid);
	pointcloudsMapper->ScalarVisibilityOn();
	pointcloudsMapper->SetScalarRange(0, number - 1);
	pointcloudsMapper->SetLookupTable(lutpointclouds);
	anActorrgbpointclouds->SetMapper(pointcloudsMapper);*/
	vtkSmartPointer<vtkPolyData> inputPolyData2 = vtkSmartPointer<vtkPolyData>::New();
	pcl::io::pointCloudTovtkPolyData(*playpointrgb, inputPolyData2);
	vtkSmartPointer<vtkPolyDataMapper> Mapper2 = vtkSmartPointer<vtkPolyDataMapper>::New();
	Mapper2->SetInputData(inputPolyData2);
	m_actor->SetMapper(Mapper2);
	m_renderer->ResetCamera();
}
void vtkShowRGB::slt_render()
{
	renderWindow->Render();


}
void vtkShowRGB::slt_stopandinteract()
{
    auto test=0;
    interactor->Start();
}
