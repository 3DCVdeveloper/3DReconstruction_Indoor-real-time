#include "odemetryd.h"
#include "RGBDodemetry.h"
odemetrytdd::odemetrytdd(QObject *parent) : QObject(parent)
{
    pcolorsendode =NULL;
    pdepthsendode =NULL;
//    shape.push_back(480);
//    shape.push_back(640);
//    shape.push_back(3);
//    //colortensorp = new Tensor(shape,core::Dtype::UInt16,core::Device("CPU:0"));
//    depthimage = new geometry::Image();
//    depthimage->Prepare(640,480,1,2);
////    imagedata = (uint16_t *)depthimage->GetDataPtr();
//    imagedata = new uint16_t[640*480];
////    imagedata = (uint16_t *)std::malloc(640*480);
//    input_color = new geometry::Image();
//    input_color->Prepare(640,480,3,1);
////    colorimagedata = (uint8_t *)input_color->GetDataPtr();

//    depthimageref = new geometry::Image();
//    depthimageref->Prepare(640,480,1,2);
////    imagedataref = (uint16_t *)depthimageref->GetDataPtr();
////    imagedata = new uint16_t[640*480];
////    imagedata = (uint16_t *)std::malloc(640*480);
//    input_colorref = new geometry::Image();
//    input_colorref->Prepare(640,480,1,2);
//    colorimagedataref = (uint8_t *)input_colorref->GetDataPtr();
//    colorimagedata = new uint8_t[640*480*3];
//    colorimagedata = (uint8_t *)std::malloc(640*480*3);
    max_depth = MAX_DISTANCE;

    min_depth = MIN_DISTANCE;
    astra_index =0;
    colorcoming =false;
    depthcoming =false;
//    T_frame_to_model = Tensor::Eye(4, core::Dtype::Float64, core::Device("CPU:0"));
    voxel_size = 2.f*3.f / 512.f;
    sdf_trunc = 0.04f;
    block_resolution = 16;
    block_count = 10000;
    depth_scale = 1000.f;
    depth_max = 4.f;
    depth_diff = 0.07f;
    odo_init = Eigen::Matrix4d::Identity();
    trans_odo = Eigen::Matrix4d::Identity();
    pcolorsendode = new RGB888Pixel[640*480];
    pdepthsendode = new DepthPixel[640*480];
//    pclstreamor = new pclshowstream();
//    info_odo = Eigen::Matrix6d::Zero();
//    model = new t::pipelines::slam::Model(voxel_size, sdf_trunc, block_resolution,
//                                          block_count, T_frame_to_model, core::Device("CPU:0"));//("CUDA:0")

}
void odemetrytdd::cloudviewONEcloudwithoutnormals(pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr cloud_source)
{

    pcl::visualization::PCLVisualizer viewercolortset;
    viewercolortset.setPosition(700, 500);
    viewercolortset.setWindowName("contour show");


    viewercolortset.setBackgroundColor(1, 1, 1, 0); // Setting background to a dark grey

    // Define R,G,B colors for the point cloud
    pcl::visualization::PointCloudColorHandlerRGBField<pcl::PointXYZRGB> source_cloud_color_handler(cloud_source);
 //pcl::visualization::PointCloudColorHandlerRGBField<pcl::PointXYZRGB> rgb(cloud);
    //Eigen::Vector4f centroid;
    //pcl::compute3DCentroid(*cloud_source, centroid); // 计算质心
    //// We add the point cloud to the viewer and pass the color handler
    viewercolortset.addPointCloud(cloud_source, source_cloud_color_handler, "original_cloud");


    viewercolortset.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "original_cloud");
    viewercolortset.addCoordinateSystem(1.0,0,3,0, "cloud", 0);
    viewercolortset.initCameraParameters();
//    viewercolortset.setCameraPosition(0, 0, 5, 0, 0, -5, 0);

    while (!viewercolortset.wasStopped())
    { // Display the visualiser until 'q' key is pressed
        viewercolortset.spinOnce();
    }
}
void odemetrytdd::slt_sendcolorimg(cv::Mat pcolorsend)
{
    int width=640;
    int height=480;

//        RGB888Pixel *pcolorshow = new RGB888Pixel[640*480];
//        std::copy(pcolorsend,pcolorsend+640*480,pcolorshow);


//        for (int j = 0; j < height; ++j)

//        {

//            for (int i = 0; i < width; ++i)

//            {

//                input_color->data_[j * width*3 + i*3]=pcolorshow[j * width + i].r;
//                input_color->data_[j* width*3 + i*3+1]=pcolorshow[j * width + i].g;
//                input_color->data_[(j) * width*3 + i*3+2]=pcolorshow[j * width + i].b;

//            }
//        }
//        auto test = input_color->data_[0];
//        delete pcolorshow;
//        if(astra_index==0)
//        {
//            std::copy(colorimagedata,colorimagedata+640*480*3,colorimagedataref);
//        }
        grayRef= pcolorsend;
        colorcoming = true;
        colormutex.lock();
        if(depthcoming && colorcoming)
        {


            colorcoming =false;
            depthcoming =false;
//            computeodemetry();
        }
        colormutex.unlock();

}
void odemetrytdd::PCLfilter(pcl::PointCloud<pcl::PointXYZ>::Ptr cloudSrc,
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloudDst)
{
  std::cout << "\n\n------------checking PCL ---------------- "<< std::endl;
  std::cout << "PCL(CPU) Loaded "
      << cloudSrc->width*cloudSrc->height
      << " data points from PCD file with the following fields: "
      << pcl::getFieldsList (*cloudSrc)
      << std::endl;

  std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
  std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
  std::chrono::duration<double, std::ratio<1, 1000>> time_span =
     std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);

  int nCount = cloudSrc->width * cloudSrc->height;
  float *outputData = (float *)cloudDst->points.data();
//{
//  std::cout << "\n------------checking PCL(CPU) PassThrough ---------------- "<< std::endl;

//  memset(outputData,0,sizeof(float)*4*nCount);

//  // Create the filtering object
//  pcl::PassThrough<pcl::PointXYZ> pass;
//  pass.setInputCloud (cloudSrc);
//  pass.setFilterFieldName ("x");
//  pass.setFilterLimits (-0.5, 0.5);
//  pass.setFilterLimitsNegative (false);

//  t1 = std::chrono::steady_clock::now();
//  pass.filter (*cloudDst);
//  t2 = std::chrono::steady_clock::now();

//  time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
//  std::cout << "PCL(CPU) PassThrough by Time: " << time_span.count() << " ms."<< std::endl;

//  std::cout << "PointCloud before filtering: " << cloudSrc->width * cloudSrc->height
//   << " data points (" << pcl::getFieldsList (*cloudSrc) << ")." << std::endl;
//  std::cout << "PointCloud after filtering: " << cloudDst->width * cloudDst->height
//     << " data points (" << pcl::getFieldsList (*cloudDst) << ")." << std::endl;
//  pcl::io::savePCDFileASCII ("after-pcl-PassThrough.pcd", *cloudDst);
//}

{
  std::cout << "\n------------checking PCL VoxelGrid---------------- "<< std::endl;

  memset(outputData,0,sizeof(float)*4*nCount);

  t1 = std::chrono::steady_clock::now();

  // Create the filtering object
  pcl::VoxelGrid<pcl::PointXYZ> sor;
  sor.setInputCloud (cloudSrc);
  sor.setLeafSize (1, 1, 1);
  sor.filter (*cloudDst);

  t2 = std::chrono::steady_clock::now();
  time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
  std::cout << "PCL VoxelGrid by Time: " << time_span.count() << " ms."<< std::endl;
  std::cout << "PointCloud before filtering: " << cloudSrc->width * cloudSrc->height
   << " data points (" << pcl::getFieldsList (*cloudSrc) << ")." << std::endl;
  std::cout << "PointCloud after filtering: " << cloudDst->width * cloudDst->height
     << " data points (" << pcl::getFieldsList (*cloudDst) << ")." << std::endl;

//  pcl::io::savePCDFileASCII ("after-pcl-VoxelGrid.pcd", *cloudDst);
}

}
void odemetrytdd::CUDAfileter(pcl::PointCloud<pcl::PointXYZ>::Ptr cloudSrc,
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloudDst, float voxelsize)
{
  std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
  std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
  std::chrono::duration<double, std::ratio<1, 1000>> time_span =
     std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
  cudaStream_t stream = NULL;
  cudaStreamCreate ( &stream );

  unsigned int nCount = cloudSrc->points.size();
  float *inputData = (float *)cloudSrc->points.data();



  std::cout << "\n------------checking CUDA ---------------- "<< std::endl;
  std::cout << "CUDA Loaded "
      << cloudSrc->width*cloudSrc->height
      << " data points from PCD file with the following fields: "
      << std::endl;

  float *input = NULL;
  cudaMallocManaged(&input, sizeof(float) * 4 * nCount, cudaMemAttachHost);
  cudaStreamAttachMemAsync (stream, input );
  cudaMemcpyAsync(input, inputData, sizeof(float) * 4 * nCount, cudaMemcpyHostToDevice, stream);
  cudaStreamSynchronize(stream);

  float *output = NULL;
  cudaMallocManaged(&output, sizeof(float) * 4 * nCount, cudaMemAttachHost);
  cudaStreamAttachMemAsync (stream, output );
  cudaStreamSynchronize(stream);

  cudaFilter filterTest(stream);
  FilterParam_t setP;
  FilterType_t type;

//{
//  unsigned int countLeft = 0;
//  std::cout << "\n------------checking CUDA PassThrough ---------------- "<< std::endl;

//  memset(outputData,0,sizeof(float)*4*nCount);

//  FilterType_t type = PASSTHROUGH;

//  setP.type = type;
//  setP.dim = 0;
//  setP.upFilterLimits = 0.5;
//  setP.downFilterLimits = -0.5;
//  setP.limitsNegative = false;
//  filterTest.set(setP);

//  cudaDeviceSynchronize();
//  t1 = std::chrono::steady_clock::now();
//  filterTest.filter(output, &countLeft, input, nCount);
//  checkCudaErrors(cudaMemcpyAsync(outputData, output, sizeof(float) * 4 * countLeft, cudaMemcpyDeviceToHost, stream));
//  checkCudaErrors(cudaDeviceSynchronize());
//  t2 = std::chrono::steady_clock::now();
//  time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
//  std::cout << "CUDA PassThrough by Time: " << time_span.count() << " ms." << std::endl;
//  std::cout << "CUDA PassThrough before filtering: " << nCount << std::endl;
//  std::cout << "CUDA PassThrough after filtering: " << countLeft << std::endl;

//  pcl::PointCloud<pcl::PointXYZ>::Ptr cloudNew(new pcl::PointCloud<pcl::PointXYZ>);
//  cloudNew->width = countLeft;
//  cloudNew->height = 1;
//  cloudNew->points.resize (cloudNew->width * cloudNew->height);

//  int check = 0;
//  for (std::size_t i = 0; i < cloudNew->size(); ++i)
//  {
//      cloudNew->points[i].x = output[i*4+0];
//      cloudNew->points[i].y = output[i*4+1];
//      cloudNew->points[i].z = output[i*4+2];
//  }
////  pcl::io::savePCDFileASCII ("after-cuda-PassThrough.pcd", *cloudNew);
//}

{
  unsigned int countLeft = 0;
  std::cout << "\n------------checking CUDA VoxelGrid---------------- "<< std::endl;

//  memset(outputData,0,sizeof(float)*4*nCount);

  type = VOXELGRID;

  setP.type = type;
  setP.voxelX = voxelsize;//0.040;
  setP.voxelY = voxelsize;//0.040;
  setP.voxelZ = voxelsize;//0.040;

  filterTest.set(setP);
  int status = 0;
  cudaDeviceSynchronize();
  t1 = std::chrono::steady_clock::now();
  status = filterTest.filter(output, &countLeft, input, nCount);
  cudaDeviceSynchronize();
  t2 = std::chrono::steady_clock::now();

  if (status != 0)
    return;
  time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
  std::cout << "CUDA VoxelGrid by Time: " << time_span.count() << " ms."<< std::endl;
  std::cout << "CUDA VoxelGrid before filtering: " << nCount << std::endl;
  std::cout << "CUDA VoxelGrid after filtering: " << countLeft << std::endl;
  cloudDst->width  = countLeft;
  cloudDst->height = 1;
  cloudDst->resize (cloudDst->width * cloudDst->height);

  float *outputData = (float *)cloudDst->points.data();

  memset(outputData,0,sizeof(float)*4*countLeft);
//  pcl::PointCloud<pcl::PointXYZ>::Ptr cloudNew(new pcl::PointCloud<pcl::PointXYZ>);
//  cloudNew->width = countLeft;
//  cloudNew->height = 1;
//  cloudNew->points.resize (cloudNew->width * cloudNew->height);

  int check = 0;
  for (std::size_t i = 0; i < countLeft; ++i)
  {
     outputData[i*4+0] = output[i*4+0];
     outputData[i*4+1] = output[i*4+1];
     outputData[i*4+2] = output[i*4+2];
  }
//  pcl::io::savePCDFileASCII ("after-cuda-VoxelGrid.pcd", *cloudNew);
}

  cudaFree(input);
  cudaFree(output);
  cudaStreamDestroy(stream);
}
double odemetrytdd::calculateFitneeScore(pcl::PointCloud<pcl::PointXYZ>::Ptr P,
        pcl::PointCloud<pcl::PointXYZ>::Ptr Q,
        Eigen::Matrix4f transformation_matrix)
{
  double fitness_score = 0.0;
  pcl::PointCloud<pcl::PointXYZ> input_transformed;
  pcl::transformPointCloud (*P, input_transformed, transformation_matrix);

  pcl::search::KdTree<pcl::PointXYZ> tree_;
  std::vector<int> nn_indices (1);
  std::vector<float> nn_dists (1);

  tree_.setInputCloud(Q);
  int nr = 0;
  for (std::size_t i = 0; i < input_transformed.points.size (); ++i)
  {
    // Find its nearest neighbor in the target
    tree_.nearestKSearch (input_transformed.points[i], 1, nn_indices, nn_dists);
    if (nn_dists[0] <=  std::numeric_limits<double>::max ())
    {
      // Add to the fitness score
      fitness_score += nn_dists[0];
      nr++;
    }
  }
  if (nr > 0)
    return (fitness_score / nr);
  return (std::numeric_limits<double>::max ());
}
void odemetrytdd::print4x4Matrix(const Eigen::Matrix4f & matrix)
{
    std::cout<<"Rotation matrix :"<<std::endl;
    std::cout<<matrix(0, 0)<<" "<<matrix(0, 1)<<" "<<matrix(0, 2)<<std::endl;
    std::cout<<matrix(1, 0)<<" "<<matrix(1, 1)<<" "<<matrix(1, 2)<<std::endl;
    std::cout<<matrix(2, 0)<<" "<<matrix(2, 1)<<" "<<matrix(2, 2)<<std::endl;
//    printf("    | %f %f %f | \n", matrix(0, 0), matrix(0, 1), matrix(0, 2));
//    printf("R = | %f %f %f | \n", matrix(1, 0), matrix(1, 1), matrix(1, 2));
//    printf("    | %f %f %f | \n", matrix(2, 0), matrix(2, 1), matrix(2, 2));
    printf("Translation vector :\n");
    std::cout<<"Translation vector :"<<std::endl;
    std::cout<<matrix(0,3)<<" "<<matrix(1,3)<<" "<<matrix(2, 3)<<std::endl;
//    printf("t = < %f, %f, %f >\n\n", matrix(0, 3), matrix(1, 3), matrix(2, 3));
}
void odemetrytdd::testPCLICP(pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_in,
        pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_out,
        Iter_para iter)
{
    std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
    std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::ratio<1, 1000>> time_span =
       std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);

    std::cout << "------------checking PCL ICP(CPU)---------------- "<< std::endl;
    int pCount = pcl_cloud_in->size();

    pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
    icp.setTransformationEpsilon(iter.threshold);
    icp.setMaxCorrespondenceDistance(2);
    icp.setMaximumIterations(iter.Maxiterate);
    icp.setRANSACIterations(0);  
    icp.setInputSource(pcl_cloud_in);
    icp.setInputTarget(pcl_cloud_out);

    pcl::PointCloud<pcl::PointXYZ>::Ptr transformedP (new pcl::PointCloud<pcl::PointXYZ>(pCount, 1));

    t1 = std::chrono::steady_clock::now();
    icp.align(*transformedP);
    t2 = std::chrono::steady_clock::now();
    time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
    std::cout << "PCL icp.align Time: " << time_span.count() << " ms."<< std::endl;
    // std::cout << "has converged: " << icp.hasConverged() << " score: " <<
    //     icp.getFitnessScore() << std::endl;
    // std::cout << "CUDA ICP fitness_score: " << calculateFitneeScore( pcl_cloud_in, pcl_cloud_out, icp.getFinalTransformation ()) << std::endl;

    auto transformation_matrix =  icp.getFinalTransformation ();
    std::cout << "transformation_matrix:\n"<<transformation_matrix << std::endl;
    std::cout << std::endl;

    auto cloudSrc = pcl_cloud_in;
    auto cloudDst = pcl_cloud_out;

    pcl::PointCloud<pcl::PointXYZ> input_transformed;
    pcl::transformPointCloud (*cloudSrc, input_transformed, transformation_matrix);

    // pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudSrcRGB (new pcl::PointCloud<pcl::PointXYZRGB>(cloudSrc->size(),1));
    // pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudDstRGB (new pcl::PointCloud<pcl::PointXYZRGB>(cloudDst->size(),1));
    // pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudALL (new pcl::PointCloud<pcl::PointXYZRGB>(cloudSrc->size() + cloudDst->size(),1));
    // // Fill in the CloudIn data
    // for (int i = 0; i < cloudSrc->size(); i++)
    // {
    //     pcl::PointXYZRGB &pointin = (*cloudSrcRGB)[i];
    //     pointin.x = (input_transformed)[i].x;
    //     pointin.y = (input_transformed)[i].y;
    //     pointin.z = (input_transformed)[i].z;
    //     pointin.r = 255;
    //     pointin.g = 0;
    //     pointin.b = 0;
    //     (*cloudALL)[i] = pointin;
    // }
    // for (int i = 0; i < cloudDst->size(); i++)
    // {
    //     pcl::PointXYZRGB &pointout = (*cloudDstRGB)[i];
    //     pointout.x = (*cloudDst)[i].x;
    //     pointout.y = (*cloudDst)[i].y;
    //     pointout.z = (*cloudDst)[i].z;
    //     pointout.r = 0;
    //     pointout.g = 255;
    //     pointout.b = 255;
    //     (*cloudALL)[i+cloudSrc->size()] = pointout;
    // }

    // pcl::io::savePCDFile<pcl::PointXYZRGB> ("ICP.pcd", *cloudALL);
}
void odemetrytdd::cudaIICP(pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_in,
        pcl::PointCloud<pcl::PointXYZ>::Ptr pcl_cloud_out,
        Iter_para iter, Eigen::Matrix4f &transformation_matrix)
{
    int nP = pcl_cloud_in->size();
    int nQ = pcl_cloud_out->size();
    float *nPdata = (float *)pcl_cloud_in->points.data();
    float *nQdata = (float *)pcl_cloud_out->points.data();
    std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
    std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::ratio<1, 1000>> time_span =
       std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);

    Eigen::Matrix4f matrix_icp = Eigen::Matrix4f::Identity();
    //std::cout << "matrix_icp native value "<< std::endl;
    //print4x4Matrix(matrix_icp);
    void *cudaMatrix = NULL;
    cudaMatrix = malloc(sizeof(float)*4*4);
    memset(cudaMatrix, 0 , sizeof(float)*4*4);
    std::cout << "------------checking CUDA ICP(GPU)---------------- "<< std::endl;
    /************************************************/
    cudaStream_t stream = NULL;
    cudaStreamCreate ( &stream );

    float *PUVM = NULL;
    cudaMallocManaged(&PUVM, sizeof(float) * 4 * nP, cudaMemAttachHost);
    cudaStreamAttachMemAsync (stream, PUVM );
    cudaMemcpyAsync(PUVM, nPdata, sizeof(float) * 4 * nP, cudaMemcpyHostToDevice, stream);

    float *QUVM = NULL;
    cudaMallocManaged(&QUVM, sizeof(float) * 4 * nQ, cudaMemAttachHost);
    cudaStreamAttachMemAsync (stream, QUVM );
    cudaMemcpyAsync(QUVM, nQdata, sizeof(float) * 4 * nQ, cudaMemcpyHostToDevice, stream);

    cudaStreamSynchronize(stream);

    cudaICP icpTest(nP, nQ, stream);

    t1 = std::chrono::steady_clock::now();
    icpTest.icp((float*)PUVM, nP, (float*)QUVM, nQ, iter.Maxiterate, iter.threshold, cudaMatrix, stream);
    t2 = std::chrono::steady_clock::now();
    time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
    std::cout << "CUDA ICP by Time: " << time_span.count() << " ms."<< std::endl;
    cudaStreamDestroy(stream);
    /************************************************/
    memcpy(matrix_icp.data(), cudaMatrix, sizeof(float)*4*4);
    transformation_matrix = matrix_icp;
    std::cout << "CUDA ICP fitness_score: " << calculateFitneeScore( pcl_cloud_in, pcl_cloud_out, transformation_matrix) << std::endl;
    std::cout << "matrix_icp calculated Matrix by Class ICP "<< std::endl;
    print4x4Matrix(matrix_icp);

    cudaFree(PUVM);
    cudaFree(QUVM);
    free(cudaMatrix);
//    auto cloudSrc = pcl_cloud_in;
//    auto cloudDst = pcl_cloud_out;
//    pcl::PointCloud<pcl::PointXYZ> input_transformed;
//    pcl::transformPointCloud (*cloudSrc, input_transformed, transformation_matrix);

//    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudSrcRGB (new pcl::PointCloud<pcl::PointXYZRGB>(cloudSrc->size(),1));
//    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudDstRGB (new pcl::PointCloud<pcl::PointXYZRGB>(cloudDst->size(),1));
//    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudALL (new pcl::PointCloud<pcl::PointXYZRGB>(cloudSrc->size() + cloudDst->size(),1));
//    // Fill in the CloudIn data
//    for (int i = 0; i < cloudSrc->size(); i++)
//    {
//        pcl::PointXYZRGB &pointin = (*cloudSrcRGB)[i];
//        pointin.x = (input_transformed)[i].x;
//        pointin.y = (input_transformed)[i].y;
//        pointin.z = (input_transformed)[i].z;
//        pointin.r = 255;
//        pointin.g = 0;
//        pointin.b = 0;
//        (*cloudALL)[i] = pointin;
//    }
//    for (int i = 0; i < cloudDst->size(); i++)
//    {
//        pcl::PointXYZRGB &pointout = (*cloudDstRGB)[i];
//        pointout.x = (*cloudDst)[i].x;
//        pointout.y = (*cloudDst)[i].y;
//        pointout.z = (*cloudDst)[i].z;
//        pointout.r = 0;
//        pointout.g = 255;
//        pointout.b = 255;
//        (*cloudALL)[i+cloudSrc->size()] = pointout;
//    }
}

void odemetrytdd::slt_senddepthimg(cv::Mat pdepthsend)
{

//        std::copy(pdepthsend,pdepthsend+640*480,(DepthPixel*)depthimage->data_.data());
//        std::vector<uint8_t> testdept=depthimage->data_;
//        auto test= ((DepthPixel*)depthimage->data_.data())[100];
//        geometry::RGBDImage::CreateFromTUMFormat();
        //io::CreateImageFromFile();
        depthRef = pdepthsend;
        depthcoming = true;
        depthmutex.lock();
        if(depthcoming && colorcoming)
        {

            colorcoming =false;
            depthcoming =false;
            computeodemetry();
        }
        depthmutex.unlock();

}
void odemetrytdd::slt_setintrinsic(double fx, double fy, double cx, double cy)
{
    intrinsiccv << fx, 0, cx,
                   0, fy, cy,
                   0, 0, 1;
//    intrinsic_t = Tensor::Init<double>(
//            {{fx, 0, cx},
//             {0, fy, cy},
//             {0, 0, 1}});
//    pinholeintrinsic.SetIntrinsics(640,480,fx,fy,cx,cy);
    dvo.init(640, 480, intrinsiccv);
    absPose = Eigen::Matrix4f::Identity();
    poses.push_back(absPose);
//    raycast_frame = new t::pipelines::slam::Frame(depthimageref->GetRows(), depthimageref->GetCols(), intrinsic_t, core::Device("CPU:0"));
//    input_frame = new t::pipelines::slam::Frame(depthimageref->GetRows(), depthimageref->GetCols(), intrinsic_t, core::Device("CPU:0"));

    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudNewref(new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudshow(new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudNew(new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloudcmpref(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloudcmpmodel(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointNormal>::Ptr cloudNewrefnormal(new pcl::PointCloud<pcl::PointNormal>);
    pointcomputefastrefnormal = cloudNewrefnormal;


    pointcomputefastref = cloudNewref;
//    pointshowref= cloudNewref;
    pointshow= cloudNew;
    pointref = cloudcmpref;
    pointmodel = cloudcmpmodel;
    pcl::PointXYZRGB reference;
    reference.x=0;
    reference.y=0;
    reference.z=0;
    reference.r=0;
    reference.g=0;
    reference.b=0;
    cloudshow->points.push_back(reference);
//    viewerthread = simpleVis(cloudshow);
    astra_index=0;
//    min_depth=800;
//    max_depth=4000;
//    boost::thread vthread(&viewerRunner,viewer);
    emit sgnl_initvtk();
//    pclstreamor->initshowstream(cloudshow);
//    pclstreamor->start();
}
boost::shared_ptr<pcl::visualization::PCLVisualizer> odemetrytdd::simpleVis (pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr cloud)
{
        // --------------------------------------------
        // -----Open 3D viewer and add point cloud-----
        // --------------------------------------------
        boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("3D Viewer"));
        viewer->setCameraPosition(0, 0, 0, 0, 0, 0, 0, 0, -1);
        viewer->setBackgroundColor(0,0,0);
        viewer->addPointCloud<pcl::PointXYZRGB> (cloud, "sample cloud");
        viewer->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "sample cloud");
        viewer->initCameraParameters ();
        return (viewer);
}

void odemetrytdd::viewerRunner(boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer)
{
        while (!viewer->wasStopped ())
        {
               viewer->spinOnce (100);
//               boost::this_thread::sleep (boost::posix_time::microseconds (100));
        }
}
void odemetrytdd::slt_sendicpcolorimg(RGB888Pixel* pcolorsend)
{
    std::copy(pcolorsend,pcolorsend+640*480,pcolorsendode);
//    depthRef = pdepthsend;
    //grayRef= pcolorsend;
    colorcoming = true;
    colormutex.lock();
    if(depthcoming && colorcoming)
    {


        colorcoming =false;
        depthcoming =false;
//            computeodemetry();
    }
    colormutex.unlock();
}
void odemetrytdd::slt_sendicpdepthimg(DepthPixel* pdepthsend)
{
    std::copy(pdepthsend,pdepthsend+640*480,pdepthsendode);
//    depthRef = pdepthsend;
    depthcoming = true;
    depthmutex.lock();
    if(depthcoming && colorcoming)
    {

        colorcoming =false;
        depthcoming =false;
//        computeodemetry();
        computepointodemetry();
    }
    depthmutex.unlock();
}
void odemetrytdd::slt_stop()
{
//    dvo.freePyramidCuda(depthRefPyramid);
//    dvo.freePyramidCuda(grayRefPyramid);
}
void odemetrytdd::addNormal(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud,pcl::PointCloud<pcl::PointNormal>::Ptr normals,
	       pcl::PointCloud<pcl::PointXYZRGBNormal>::Ptr cloud_with_normals
)
{
  pcl::concatenateFields( *cloud, *normals, *cloud_with_normals );
}
void odemetrytdd::computepointodemetry()
{

    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudNew(new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudNewcurr(new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloudafterfilter(new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloudcmp(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloudcmpI(new pcl::PointCloud<pcl::PointXYZI>);
    cloud_after_bilateralFilter = cloudafterfilter;
         pcl::PointCloud<pcl::PointNormal>::Ptr cloudcurrnormal(new pcl::PointCloud<pcl::PointNormal>);
   
    pointcomputefastnormal = cloudcurrnormal;
    if(0==astra_index)
    {

        if(pointcomputefastref->points.size()>0)
        {
            pointcomputefastref->points.clear();
            pointcomputefastrefnormal->points.clear();
        }
    }
    pointcurrent = cloudcmp;
    pointcurrentI = cloudcmpI;
    pointcomputefast = cloudNew;
//    pointcomputefast->width = 640;
//    pointcomputefast->height = 480;
//    pointcomputefast->resize(480*640);

//    pointcomputefastref->width = 640;
//    pointcomputefastref->height = 480;
//    pointcomputefastref->resize(480 * 640);
    float world_x, world_y, world_z;
    std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
    std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::ratio<1, 1000>> time_span =
    std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
    t1 = std::chrono::steady_clock::now();
    int valuedsize=0;
    for (int v = 0; v < 480; ++v)
    {
        for (int u = 0; u < 640; ++u)
        {
            uint16_t depth = pdepthsendode[v * 640 + u];
           
            if (depth <= 0 || depth < min_depth || depth > max_depth)
                continue;

            valuedsize++;
            //  if(0!=(v * 640 + u)%5)
            // {
            //     continue;
            // }
            //分辨率缩放，这里假设标定时的分辨率分RESOULTION_X，RESOULTION_Y// * ((float)(width) / RESOULTION_X)//

            float fdx = intrinsiccv(0,0);

            float fdy = intrinsiccv(1,1) ;//* ((float)(height) / RESOULTION_Y);

            float u0 = intrinsiccv(0,2) ;//* ((float)(width) / RESOULTION_X);

            float v0 = intrinsiccv(1,2) ;//* ((float)(height) / RESOULTION_Y);

            float tx = (u - u0) / fdx;

            float ty = (v - v0) / fdy;

            world_x = ((float)depth) * tx/1000;

            world_y = ((float)depth) * ty/1000;

            world_z = ((float)depth)/1000;

        //      float dzdx = (pdepthsendode[v * 640 + u+1]- pdepthsendode[v * 640 + u-1]) / 2000.0;
        // float dzdy = (pdepthsendode[(v+1) * 640 + u]- pdepthsendode[(v-1) * 640 + u-1]) / 2000.0;
        //     pcl::PointNormal normal;
        //     normal.normal_x = dzdx;
        //     normal.normal_y = dzdx;
        //     normal.normal_z = 1;
            pcl::PointXYZRGB point;
////            pcl::PointXYZ pointcompute;
//            pcl::PointXYZI pointbifilter;
////            pointcompute.x = world_x;
//
////            pointcompute.y = -world_y;
//
////            pointcompute.z = -world_z;
//
            point.x = world_x;
//
            point.y = -world_y;
//
            point.z = world_z;
//            pointbifilter.intensity = (float)((pcolorsendode[v * 640 + u].r*19595 + pcolorsendode[v * 640 + u].g*38469 + pcolorsendode[v * 640 + u].b*7472) >> 16);
//            pointbifilter.x=world_x;
//            pointbifilter.y=-world_y;
//            pointbifilter.z=-world_z;
            point.r = pcolorsendode[v * 640 + u].r;
            point.g = pcolorsendode[v * 640 + u].g;
            point.b = pcolorsendode[v * 640 + u].b;
            if(0==astra_index)
            {
//                pointcomputefastref->at(u,v).x = world_x;
//                pointcomputefastref->at(u,v).y = -world_y;
//                pointcomputefastref->at(u,v).z = world_z;
//                pointcomputefastref->at(u,v).r = pcolorsendode[v * 640 + u].r;
//                pointcomputefastref->at(u,v).g = pcolorsendode[v * 640 + u].g;
//                pointcomputefastref->at(u,v).b = pcolorsendode[v * 640 + u].b;
                pointcomputefastref->points.push_back(point);
                // pointcomputefastrefnormal->points.push_back(normal);
                //pointref->points.push_back(pointcompute);
            }
            else
            {
//                pointcomputefast->at(u,v).x = world_x;
//                pointcomputefast->at(u,v).y = -world_y;
//                pointcomputefast->at(u,v).z = world_z;
//                pointcomputefast->at(u,v).r = pcolorsendode[v * 640 + u].r;
//                pointcomputefast->at(u,v).g = pcolorsendode[v * 640 + u].g;
//                pointcomputefast->at(u,v).b = pcolorsendode[v * 640 + u].b;
                pointcomputefast->points.push_back(point);
                // pointcomputefastnormal->points.push_back(normal);
                //pointshow->points.push_back(point);
                //pointcurrent->points.push_back(pointcompute);
            }

        }

    }
    t2 = std::chrono::steady_clock::now();
	time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
	std::cout << "depth to point cloud by Time: " << time_span.count() << " ms." << std::endl;
    
    
    //yu chu li
    if (0 == astra_index)
    {
        if(valuedsize>130000)
        {
//            cloudviewONEcloudwithoutnormals(pointcomputefastref);
            // pcl::PointCloud<pcl::PointXYZ>::Ptr showmodelcloud(new pcl::PointCloud<pcl::PointXYZ>);
            // pcl::copyPointCloud(*pointcomputefastref, *showmodelcloud);
//            emit sgnl_updatepointcloud(showmodelcloud);
//            emit sgnl_rendervtk();
//            pclstreamor->slt_setCloud(pointcomputefastref);
            t1 = std::chrono::steady_clock::now();

            /*pcl::FastBilateralFilter<pcl::PointXYZRGB> fastbilateralfilter;
            fastbilateralfilter.setInputCloud(pointcomputefastref);
            fastbilateralfilter.setSigmaS(0.0058);
            fastbilateralfilter.setSigmaR(0.03);
            fastbilateralfilter.filter(*cloud_after_bilateralFilter);//存储滤波后的数据格式*/
//            pcl::PointCloud<pcl::PointXYZI>::Ptr curcloud_after_bilateralTST1(new pcl::PointCloud<pcl::PointXYZI>);
//            pcl::search::KdTree<pcl::PointXYZI>::Ptr tree1(new pcl::search::KdTree<pcl::PointXYZI>);
//            pcl::BilateralFilter<pcl::PointXYZI> bf;
//            bf.setInputCloud(pointcomputefastref);
//            bf.setSearchMethod(tree1);
//            bf.setHalfSize(0.0058);
//            bf.setStdDev(0.03);
//            bf.filter(*curcloud_after_bilateralTST1);
    //统计滤波
//    std::cout << "before StatisticalOutlierRemoval pointcomputefastref ref size = " << pointcomputefastref->size() << std::endl;
//	pcl::StatisticalOutlierRemoval<pcl::PointXYZRGB> outrem;//创建统计滤波对象

//	//参数设置
//	outrem.setInputCloud(pointcomputefastref);
//    outrem.setMeanK(10);//附近邻近点数
//	outrem.setStddevMulThresh(1);//判断是否离群点
//	outrem.filter(*cloud_after_bilateralFilter);

//            std::cout << "after StatisticalOutlierRemoval ref size = " << cloud_after_bilateralFilter->size() << std::endl;
//                    t2 = std::chrono::steady_clock::now();

//                    time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
//                    std::cout << "PCL(CPU) StatisticalOutlierRemoval by Time: " << time_span.count() << " ms." << std::endl;
                pcl::VoxelGrid<pcl::PointXYZRGB> sor;
                sor.setInputCloud(pointcomputefastref);
                sor.setLeafSize(0.015, 0.015, 0.015);
                sor.filter(*pointshow);
//            *pointshow = *pointcomputefastref;

//            cloudviewONEcloudwithoutnormals(cloud_after_bilateralFilter);
                  //  pcl::PointCloud<pcl::PointXYZ>::Ptr showmodelcloud(new pcl::PointCloud<pcl::PointXYZ>);
//                    pcl::copyPointCloud(*cloud_after_bilateralFilter, *showmodelcloud);
//            emit sgnl_updatepointcloud(showmodelcloud);
//            emit sgnl_rendervtk();
            //passthrough
//            pcl::PassThrough<pcl::PointXYZRGB> passref;
//            passref.setInputCloud(cloud_after_bilateralFilter);
//            passref.setFilterFieldName("z");
//            passref.setFilterLimits(0.8, 4);
//            passref.setFilterLimitsNegative(false);

//            t1 = std::chrono::steady_clock::now();
//            passref.filter(*cloud_after_bilateralFilter);
//            t2 = std::chrono::steady_clock::now();

//            time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
//            std::cout << "PCL(CPU) PassThrough by Time: " << time_span.count() << " ms." << std::endl;
//            std::cout << "after passthrough ref size " << cloud_after_bilateralFilter->size() << std::endl;
//            cloudviewONEcloudwithoutnormals(cloud_after_bilateralFilter);
        }
    }
    if(astra_index>0)
    {
        //filter fast
        if(valuedsize>130000)
        {
//            cloudviewONEcloudwithoutnormals(pointcomputefast);
//            pclstreamor->slt_setCloud(pointcomputefast);
//            boost::mutex::scoped_lock updateLock(updateModelMutex);
//                           viewerthread->updatePointCloud<pcl::PointXYZRGB>(pointcomputefast,"sample cloud");
//                           updateLock.unlock();
            t1 = std::chrono::steady_clock::now();
            // pcl::PointCloud<pcl::PointXYZRGB>::Ptr curcloud_after_bilateralFilter(new pcl::PointCloud<pcl::PointXYZRGB>);
//            pcl::FastBilateralFilter<pcl::PointXYZRGB> curfastbilateralfilter;
//            curfastbilateralfilter.setInputCloud(pointcomputefast);
//            curfastbilateralfilter.setSigmaS(0.0058);
//            curfastbilateralfilter.setSigmaR(0.03);
//            curfastbilateralfilter.filter(*curcloud_after_bilateralFilter);//存储滤波后的数据格式
//            pcl::StatisticalOutlierRemoval<pcl::PointXYZRGB> outrem;//创建统计滤波对象

//            //参数设置
//            outrem.setInputCloud(pointcomputefast);
//            outrem.setMeanK(10);//附近邻近点数
//            outrem.setStddevMulThresh(1);//判断是否离群点
//            outrem.filter(*curcloud_after_bilateralFilter);
//            std::cout << "after fastbilateralfilter current size = " << curcloud_after_bilateralFilter->size() << endl;
            //


            // t2 = std::chrono::steady_clock::now();
            // time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
            // std::cout << "PCL StatisticalOutlierRemoval fastbilateralfilter by Time: " << time_span.count() << " ms." << std::endl;


            std::cout << "passthrough" << endl;




//            pcl::PassThrough<pcl::PointXYZRGB> passrcur;
//            passrcur.setInputCloud(curcloud_after_bilateralFilter);
//            passrcur.setFilterFieldName("z");
//            passrcur.setFilterLimits(0.8, 4);
//            passrcur.setFilterLimitsNegative(false);

//            t1 = std::chrono::steady_clock::now();
//            passrcur.filter(*curcloud_after_bilateralFilter);
//            t2 = std::chrono::steady_clock::now();

//            time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
//            std::cout << "PCL(CPU) PassThrough by Time: " << time_span.count() << " ms." << std::endl;
//            std::cout << "after passthrough current size " << curcloud_after_bilateralFilter->size() << std::endl;

            //if(pointcurrent->points.size()>150000)
            {
                if (1 == astra_index)
                {
                    pcl::copyPointCloud(*pointcomputefastref, *pointref);
                }
                pcl::copyPointCloud(*pointcomputefast, *pointcurrent);

                 pcl::PointCloud<pcl::PointXYZRGBNormal>::Ptr cloud_source_normals ( new pcl::PointCloud<pcl::PointXYZRGBNormal> () );
  pcl::PointCloud<pcl::PointXYZRGBNormal>::Ptr cloud_target_normals ( new pcl::PointCloud<pcl::PointXYZRGBNormal> () );
                // addNormal( pointcomputefastref,pointcomputefastrefnormal, cloud_target_normals );
//                pcl::RadiusOutlierRemoval<pcl::PointXYZRGBNormal> outrem;
//    // build the filter
//std::cout << "befor RadiusOutlierRemoval cloud_target_normals size " << cloud_target_normals->size() << std::endl;
//                outrem.setInputCloud(cloud_target_normals);
//                outrem.setRadiusSearch(0.02);
//                outrem.setMinNeighborsInRadius (50);
//                // apply filter
//                outrem.filter (*cloud_target_normals);

//std::cout << "after RadiusOutlierRemoval cloud_target_normals size " << cloud_target_normals->size() << std::endl;
        // addNormal( pointcomputefast,pointcomputefastnormal, cloud_source_normals );
//std::cout << "befor RadiusOutlierRemoval cloud_source_normals size " << cloud_source_normals->size() << std::endl;
        
                
//                outrem.setInputCloud(cloud_source_normals);
//                outrem.setRadiusSearch(0.02);
//                outrem.setMinNeighborsInRadius (50);
//                // apply filter
//                outrem.filter (*cloud_source_normals);
//std::cout << "after RadiusOutlierRemoval cloud_source_normals size " << cloud_source_normals->size() << std::endl;

        std::cout << "before ApproximateVoxelGrid cloud_target_normals size " << cloud_target_normals->size() << std::endl;
std::cout << "before ApproximateVoxelGrid cloud_target_normals size " << cloud_source_normals->size() << std::endl;
                Eigen::Matrix4f transformation_matrix;
//                pcl::VoxelGrid<pcl::PointXYZRGBNormal> sor;
//                sor.setInputCloud(cloud_source_normals);
//                sor.setLeafSize(0.02, 0.02, 0.02);
//                sor.filter(*cloud_source_normals);
//                 sor.setInputCloud(cloud_target_normals);
//                sor.setLeafSize(0.02, 0.02, 0.02);
//                sor.filter(*cloud_target_normals);

                pcl::PointCloud<pcl::PointXYZ>::Ptr cloudfilterref(new pcl::PointCloud<pcl::PointXYZ>);
                CUDAfileter(pointref, cloudfilterref, 0.024);
                t1 = std::chrono::steady_clock::now();
                pcl::PointCloud<pcl::PointXYZ>::Ptr cloudcurrent(new pcl::PointCloud<pcl::PointXYZ>);
               CUDAfileter(pointcurrent, cloudcurrent, 0.024);
//                pcl::ApproximateVoxelGrid<pcl::PointXYZ> approximate_voxel_filter;
//                approximate_voxel_filter.setLeafSize(0.05,0.05,0.05);
//                approximate_voxel_filter.setInputCloud(pointcurrent);
//                approximate_voxel_filter.filter(*cloudcurrent);
                t2 = std::chrono::steady_clock::now();
                time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
                std::cout << "ApproximateVoxelGrid by Time: " << time_span.count() << " ms." << std::endl;
                std::cout << "after ApproximateVoxelGrid cloud_target_normals size " << cloud_target_normals->size() << std::endl;
std::cout << "after ApproximateVoxelGrid cloud_target_normals size " << cloud_source_normals->size() << std::endl;

                pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sorstc;
                sorstc.setInputCloud(cloudfilterref);
                sorstc.setMeanK(10);
                sorstc.setStddevMulThresh(1.0);
                sorstc.filter(*cloudfilterref);

                sorstc.setInputCloud(cloudcurrent);
                sorstc.setMeanK(10);
                sorstc.setStddevMulThresh(1.0);
                sorstc.filter(*cloudcurrent);
                 halconReference = pcl2Halcon(cloudfilterref);
                 transformation_matrix = halconreg(cloudcurrent)[0].second;
//                approximate_voxel_filter.setLeafSize(0.05,0.05,0.05);
//                approximate_voxel_filter.setInputCloud(pointref);
//                approximate_voxel_filter.filter(*cloudfilterref);

//icp+ndt
//                t1 = std::chrono::steady_clock::now();
//                pcl::NormalDistributionsTransform<pcl::PointXYZ,pcl::PointXYZ>  ndt;
//                ndt.setTransformationEpsilon(0.01);
//                ndt.setStepSize(0.02);
//                ndt.setResolution(0.02);
//                ndt.setMaximumIterations(20);

//                ndt.setInputSource(cloudcurrent);
//                ndt.setInputTarget(cloudfilterref);
//                 pcl::PointCloud<pcl::PointXYZ>::Ptr ndtreg(new pcl::PointCloud<pcl::PointXYZ>);
//                // Eigen::AngleAxisf init_rotation (0,Eigen::Vector3f::UnitZ());
//                // Eigen::Translation3f init_translation (0,0,0);

//                // Eigen::Matrix4f init_guess = (init_translation*init_rotation).matrix();
//                ndt.align(*ndtreg , init_guess);

//                pcl::transformPointCloud(*cloudcurrent, *ndtreg, ndt.getFinalTransformation());
//                t2 = std::chrono::steady_clock::now();
//                time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
//                std::cout << "NormalDistributionsTransform by Time: " << time_span.count() << " ms." << std::endl;
//                std::cout << "after NormalDistributionsTransform cloudcurrent size " << ndtreg->size() << std::endl;
//icp with normal
// std::vector<int> mapping;
// pcl::removeNaNFromPointCloud(*cloud_source_normals, *cloud_source_normals, mapping);
// pcl::removeNaNFromPointCloud(*cloud_target_normals, *cloud_target_normals, mapping);
//   pcl::PointCloud<pcl::PointXYZRGBNormal>::Ptr cloud_source_normals_trans ( new pcl::PointCloud<pcl::PointXYZRGBNormal> () );
// pcl::IterativeClosestPointWithNormals<pcl::PointXYZRGBNormal, pcl::PointXYZRGBNormal> icpnormal;
//   icpnormal.setMaximumIterations ( 20 );
//   icpnormal.setInputSource ( cloud_source_normals ); // not cloud_source, but cloud_source_trans!
//   icpnormal.setInputTarget ( cloud_target_normals );
//    icpnormal.align ( *cloud_source_normals_trans ); // use cloud with normals for ICP
//    if ( icpnormal.hasConverged() )
//     {
//       // use cloud without normals for visualizatoin
//       //pcl::transformPointCloud ( *cloud_source, *cloud_source_trans, icpnormal.getFinalTransformation() );
//    transformation_matrix = icpnormal.getFinalTransformation();
//                 print4x4Matrix(transformation_matrix);
//     //   viewer->updatePointCloud ( cloud_source_trans, source_trans_color, "source trans" );
//     //   std::cout << icp->getFitnessScore() << std::endl;
//     }
//     else
//       {
//           std::cout << "Not converged." << std::endl;
//           return;
//       }
                pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
                icp.setTransformationEpsilon(0.01);
                icp.setMaxCorrespondenceDistance(0.50);
                icp.setMaximumIterations(20);
//                icp.setRANSACIterations(0);
                icp.setInputSource(cloudcurrent);
                icp.setInputTarget(cloudfilterref);

                pcl::PointCloud<pcl::PointXYZ>::Ptr transformedP (new pcl::PointCloud<pcl::PointXYZ>);

//                 t1 = std::chrono::steady_clock::now();
                icp.align(*transformedP);
//                 t2 = std::chrono::steady_clock::now();
//                 time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
//                 std::cout << "PCL icp.align Time: " << time_span.count() << " ms."<< std::endl;
                // std::cout << "has converged: " << icp.hasConverged() << " score: " <<
                //     icp.getFitnessScore() << std::endl;
                if(icp.getFitnessScore()<0.7)
                {
                    return;
                }
                // std::cout << "CUDA ICP fitness_score: " << calculateFitneeScore( pcl_cloud_in, pcl_cloud_out, icp.getFinalTransformation ()) << std::endl;

                transformation_matrix = icp.getFinalTransformation ();



                // cudaIICP(cloudfilterref,cloudcurrent,odemetryiter,transformation_matrix);
                pcl::PointCloud<pcl::PointXYZRGB>::Ptr input_transformed(new pcl::PointCloud<pcl::PointXYZRGB>);
//                cloudviewONEcloudwithoutnormals(pointcomputefast);
                pcl::transformPointCloud(*pointcomputefast, *input_transformed, transformation_matrix);
//                cloudviewONEcloudwithoutnormals(pointcomputefast);
                *pointshow += *input_transformed;
                std::cout << "before smooth pointref size " << pointshow->size() << std::endl;
                t1 = std::chrono::steady_clock::now();
                pcl::VoxelGrid<pcl::PointXYZRGB> sorshow;
                sorshow.setInputCloud(pointshow);
                sorshow.setLeafSize(0.024, 0.024, 0.024);
                sorshow.filter(*pointshow);

                t2 = std::chrono::steady_clock::now();
                time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
                std::cout << "pcl::VoxelGrid<pcl::PointXYZRGB> pointshow by Time: " << time_span.count() << " ms." << std::endl;
                //make model
                pcl::PointCloud<pcl::PointXYZ>::Ptr cloudmodel(new pcl::PointCloud<pcl::PointXYZ>);
                pcl::copyPointCloud(*pointshow, *cloudmodel);
//                pcl::PointCloud<pcl::PointXYZ>::Ptr cloudmodelshow(new pcl::PointCloud<pcl::PointXYZ>);
//                CUDAfileter(cloudmodel, cloudmodelshow, 0.0116);
//                std::cout << "after passthrough pointref size " << cloudmodelshow->size() << std::endl;
                emit sgnl_updatepointcloud(pointshow);
                emit sgnl_rendervtk();
                pcl::copyPointCloud(*pointcomputefast, *pointref);
                //show point
//                emit sgnl_manwindowshowpoint(pointshow);

                //model passthrough
                /*pcl::PointXYZ min;
                pcl::PointXYZ max;
                pcl::getMinMax3D(*input_transformed, min, max);
                pcl::PassThrough<pcl::PointXYZ> passrmodel;
                passrmodel.setInputCloud(cloudmodel);
                passrmodel.setFilterFieldName("x");
                passrmodel.setFilterLimits(min.x, max.x);
                passrmodel.setFilterLimitsNegative(false);

                t1 = std::chrono::steady_clock::now();
                passrmodel.filter(*cloudmodel);
                t2 = std::chrono::steady_clock::now();

                time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
                std::cout << "PCL(CPU)  model PassThroughx by Time: " << time_span.count() << " ms." << std::endl;
                std::cout << "after passthrough cloudmodelx size " << cloudmodel->size() << std::endl;
                pcl::PassThrough<pcl::PointXYZ> passrmodely;
                passrmodely.setInputCloud(cloudmodel);
                passrmodely.setFilterFieldName("y");
                passrmodely.setFilterLimits(min.y, max.y);
                passrmodely.setFilterLimitsNegative(false);

                t1 = std::chrono::steady_clock::now();
                passrmodely.filter(*cloudmodel);
                t2 = std::chrono::steady_clock::now();

                time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
                std::cout << "PCL(CPU) PassThrough by Time: " << time_span.count() << " ms." << std::endl;
                std::cout << "after passthrough cloudmodel y size " << cloudmodel->size() << std::endl;

                //pointref
                pcl::PassThrough<pcl::PointXYZ> passrmodelz;
                passrmodelz.setInputCloud(cloudmodel);
                passrmodelz.setFilterFieldName("z");
                passrmodelz.setFilterLimits(min.z, max.z);
                passrmodelz.setFilterLimitsNegative(false);

                t1 = std::chrono::steady_clock::now();
                passrmodelz.filter(*pointref);
                t2 = std::chrono::steady_clock::now();

                time_span = std::chrono::duration_cast<std::chrono::duration<double, std::ratio<1, 1000>>>(t2 - t1);
                std::cout << "PCL(CPU) PassThrough by Time: " << time_span.count() << " ms." << std::endl*/;
                std::cout << "after passthrough pointref z size " << pointref->size() << std::endl;

                //CUDAfileter(cloudmodel, pointmodel, 0.0058);
            }
        }
    }
    if(valuedsize>130000)
    {
        astra_index++;
    }


}
 HTuple odemetrytdd::pcl2Halcon(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud)
{
    
	size_t size = cloud->points.size();
	
	return hvalcon3d;
}
std::vector<std::pair<vector<float>, Eigen::Matrix4f>>  odemetrytdd::halconreg(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud)
{
        std::vector<std::pair<vector<float>, Eigen::Matrix4f>> MatAnPos;
        
        return MatAnPos;
 }
void odemetrytdd::computeodemetry()
{
        std::cout << "--- This is a demo:" <<std::endl;
//        runCudaPart();
        std::cout << "--- Ending ... " <<std::endl;



        if(astra_index==0)
        {

            dvo.buildPyramids(depthRef, grayRef, depthRefPyramid, grayRefPyramid);
        }
        if(astra_index>0)
        {
            cv::Mat grayCur =grayRef;
            cv::Mat depthCur= depthRef;
            std::vector<float*> grayCurPyramid; // this will store device pointers
            std::vector<float*> depthCurPyramid; // this will store device pointers
            dvo.buildPyramids(depthCur, grayCur, depthCurPyramid, grayCurPyramid);
            // frame alignment
            double tmr = (double)cv::getTickCount();
            Eigen::Matrix4f relPose = Eigen::Matrix4f::Identity();
            dvo.align(depthRefPyramid, grayRefPyramid, grayCurPyramid, relPose);
            tmr = ((double)cv::getTickCount() - tmr)/cv::getTickFrequency();
            runtimeAvg += tmr;
            // concatenate poses
            Eigen::Matrix4f rPo = relPose.inverse();
            absPose = absPose * rPo;
            poses.push_back(absPose);
            Eigen::Matrix3f tmprot = absPose.block(0, 0, 3, 3);
            Eigen::Vector3f tmptra = absPose.block(0, 3, 3, 1);
            Eigen::Vector3f camPos = - tmprot.transpose() * tmptra;
//            outFile << -camPos.x() << " " << camPos.y() << std::endl;
        // free ref pyramids
             std::cout << "camPos(0) " <<camPos(0)<<std::endl;
             std::cout << "camPos(1) " <<camPos(1)<<std::endl;
             std::cout << "camPos(2) " <<camPos(2)<<std::endl;
            camPos(0);
            camPos(1);
            camPos(2);
            dvo.freePyramidCuda(depthRefPyramid);
            dvo.freePyramidCuda(grayRefPyramid);

            depthRefPyramid = depthCurPyramid;
            grayRefPyramid = grayCurPyramid;
        }
//    using namespace open3d;
//    using core::Tensor;
////    using t::geometry::Image;
////    using t::geometry::PointCloud;
////    using t::geometry::RGBDImage;
//    bool convert_rgb_to_intensity = true;

//    if(astra_index==0)
//    {
////        std::copy(imagedata,imagedata+640*480,imagedataref);
//        source_rgbd_imageref =geometry::RGBDImage::CreateFromColorAndDepth(*input_color, *depthimage,(double)depth_scale, (double)depth_max, convert_rgb_to_intensity);
//    }
//    //t::pipelines::slam::Model model(voxel_size, sdf_trunc, block_resolution,block_count, T_frame_to_model, core::Device("CUDA:0"));
//    //t::pipelines::slam::Frame input_frame(depthimageref->GetRows(), depthimageref->GetCols(), intrinsic_t, core::Device("CPU:0"));


////    input_frame->SetDataFromImage("depth", *depthimage);
////    input_frame->SetDataFromImage("color", *input_color);
//    bool tracking_success = true;



//    if(astra_index>0)
//    {
//        std::shared_ptr<geometry::RGBDImage> source_rgbd_image = geometry::RGBDImage::CreateFromColorAndDepth(*input_color, *depthimage,(double)depth_scale, (double)depth_max, convert_rgb_to_intensity);
//        pipelines::odometry::OdometryOption option;
//        Eigen::Matrix4d odo_init = Eigen::Matrix4d::Identity();
//        Eigen::Matrix4d trans_odo = Eigen::Matrix4d::Identity();
//        Eigen::Matrix6d info_odo = Eigen::Matrix6d::Zero();
//        bool is_success;

//        pipelines::odometry::RGBDOdometryJacobianFromHybridTerm jacobian_method;
//        std::tie(is_success, trans_odo, info_odo) =
//                pipelines::odometry::ComputeRGBDOdometry(*source_rgbd_imageref, *source_rgbd_image, pinholeintrinsic,
//                                              odo_init, jacobian_method,
//                                              option);
//        std::cout << "Estimated 4x4 motion matrix : " << std::endl;
//            std::cout << trans_odo << std::endl;
//            std::cout << "Estimated 6x6 information matrix : " << std::endl;
//            std::cout << info_odo << std::endl;

////        auto testimg = input_frame->GetDataAsImage("depth");
////        auto rowstest = testimg.GetRows();
////        auto colstest = testimg.GetCols();

////        std::vector<uint16_t> colortensor;
////        std::vector<uint16_t> raycolortensor;
////        colortensor.clear();
////        for(int i =0;i<rowstest;i++)
////        {
////            for(int j =0;j<colstest;j++)
////            {
////                testimg.At(i,j);
////                colortensor.push_back(*(uint16_t*)testimg.At(i,j).GetDataPtr());

////            }
////        }

////        {
//////            raycolortensorttt.clear();
////            auto testimginputttt = raycast_frame->GetDataAsImage("depth");
////            auto rowstestinputttt = testimginputttt.GetRows();
////            auto colstestinputttt = testimginputttt.GetCols();
////            std::vector<uint16_t> raycolortensorttt;
////            uint16_t *imagedatattt=(uint16_t *)testimginputttt.GetDataPtr();
////            for(int i =0;i<rowstestinputttt;i++)
////            {
////                for(int j =0;j<colstestinputttt;j++)
////                {
////                    imagedatattt[i*rowstestinputttt+j];
////                    raycolortensorttt.push_back(imagedatattt[i*rowstestinputttt+j]);

////                }
////            }
////            auto ggg=0;
////        }

////        auto testimginput = input_frame.GetDataAsImage("depth");
////        auto rowstestinput = testimg.GetRows();
////        auto colstestinput = testimg.GetCols();

////        for(int i =0;i<rowstest;i++)
////        {
////            for(int j =0;j<rowstest;j++)
////            {
//////                testimg.At(i,j)[0];
////                raycolortensor.push_back(*(uint16_t*)testimginput.At(i,j)[0].GetDataPtr());

////            }
////        }


////        auto result = model->TrackFrameToModel(*input_frame, *raycast_frame, depth_scale, depth_max, depth_diff);

////        core::Tensor translation =
////                result.transformation_.Slice(0, 0, 3).Slice(1, 3, 4);
////        double translation_norm = std::sqrt(
////                (translation * translation).Sum({0, 1}).Item<double>());

////        // TODO(wei): more systematical failure check.
////        // If the overlap is too small or translation is too high between
////        // two consecutive frames, it is likely that the tracking failed.
////        if (result.fitness_ >= 0.1 && translation_norm < 0.15) {
////            T_frame_to_model =
////                    T_frame_to_model.Matmul(result.transformation_);
////        } else {  // Don't update
////            tracking_success = false;

////        }
////        source_rgbd_imageref =geometry::RGBDImage::CreateFromColorAndDepth(*input_color, *depthimage,(double)depth_scale, (double)depth_max, convert_rgb_to_intensity);

//    }
////    model->UpdateFramePose(astra_index, T_frame_to_model);
////    if (tracking_success) {
////        model->Integrate(*input_frame, depth_scale, depth_max);
////    }
////    model->SynthesizeModelFrame(*raycast_frame, depth_scale, 0.1, depth_max,
////                               false);
////    auto testuo = raycast_frame->GetHeight();
////    auto testuol = raycast_frame->GetWidth();
////    auto testimgeee = raycast_frame->GetDataAsImage("depth");
////    testimgeee.At(0,0)[0];
////    auto rowstest = testimgeee.GetRows();
////    auto colstest = testimgeee.GetCols();

    astra_index++;
}
void odemetrytdd::generateOffFile(std::string dataFolder, std::string rgbImage, std::string depthImage, Eigen::Matrix3f intrinsics, std::vector<Eigen::Matrix4f> poses){

    std::string visualizeFilename = "visualize.off";
    std::ofstream outFile((dataFolder + visualizeFilename).c_str());
    if (!outFile.is_open()) return;

    // Load images
    cv::Mat imgColor = cv::imread(dataFolder + rgbImage, 4);
    cv::Mat imgDepthIn = cv::imread(dataFolder + depthImage, 2);

    // write header
    outFile << "COFF" << std::endl;
    outFile << (poses.size() + (imgColor.rows * imgColor.cols)) << " 0 0" << std::endl;

    // Save camera position
    for (int i = 0; i < poses.size(); ++i) {
        Eigen::Matrix4f cameraExtrinsics = poses[i];
        Eigen::Matrix3f rotation = cameraExtrinsics.block(0, 0, 3, 3);
        Eigen::Vector3f translation = cameraExtrinsics.block(0, 3, 3, 1);
        Eigen::Vector3f cameraPosition = - rotation.transpose() * translation;
        outFile << cameraPosition.x() << " " << cameraPosition.y() << " " << cameraPosition.z() << " 255 0 0" << std::endl;
    }

    float fovX = intrinsics(0, 0);
    float fovY = intrinsics(1, 1);
    float cX = intrinsics(0, 2);
    float cY = intrinsics(1, 2);

    Eigen::Matrix4f cameraExtrinsicsInv = poses[0].inverse();
    Eigen::Matrix3f rotationInv = cameraExtrinsicsInv.block(0, 0, 3, 3);
    Eigen::Vector3f translationInv = cameraExtrinsicsInv.block(0, 3, 3, 1);

    assert(imgColor.rows == imgDepthIn.rows);
    assert(imgColor.cols == imgDepthIn.cols);

    for(int v=0; v<imgColor.rows; ++v){
        for(int u=0;u<imgColor.cols; ++u){

            cv::Point point2d = cv::Point(u,v);

            float x = ((float) u - cX) / fovX;
            float y = ((float) v - cY) / fovY;

            float depth = imgDepthIn.at<uint16_t>(point2d);

            depth *= 1.0 / 5000.0;

            Eigen::Vector4f backprojected = Eigen::Vector4f(depth * x, depth * y, depth, 1);
            Eigen::Vector4f worldSpace = cameraExtrinsicsInv * backprojected;

            cv::Vec3b colors = imgColor.at<cv::Vec3b>(v,u);

            outFile << worldSpace[0] << " " << worldSpace[1] << " " << worldSpace[2] << " " <<
            static_cast<unsigned>(colors[2]) << " " << static_cast<unsigned>(colors[1]) << " " << static_cast<unsigned>(colors[0]) <<  std::endl;
        }
    }

}
