// kernel.h

#ifndef KERNEL_H
#define KERNEL_H

extern "C" void runCudaPart();

#endif // KERNEL_H

