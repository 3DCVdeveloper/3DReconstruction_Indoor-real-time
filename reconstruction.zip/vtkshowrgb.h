#ifndef VTKSHOWRGB_H
#define VTKSHOWRGB_H

#include <QObject>
#include <pcl/io/pcd_io.h>
//#include <pcl/registration/icp.h>
//#include <pcl/registration/gicp.h>
//#include <pcl/filters/passthrough.h>
//#include <pcl/filters/voxel_grid.h>
//#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
//#include <pcl/visualization/cloud_viewer.h>
//#include <pcl/visualization/pcl_visualizer.h>
//#include <pcl/filters/fast_bilateral.h>
//#include <pcl/filters/bilateral.h>
//#include <pcl/common/common.h>
//#include "pclshowstream.h"
//#include <pcl/kdtree/flann.h>
//#include <pcl/kdtree/kdtree.h>
//#include <pcl/search/flann_search.h>
//#include <pcl/search/kdtree.h>
//#include <pcl/kdtree/kdtree_flann.h>
//#include <pcl/filters/bilateral.h>
#include <vtkProperty.h>
#include <pcl/io/vtk_lib_io.h>
#include <vtkRendererCollection.h>
#include <vtkTransform.h>
#include <vtkAxesActor.h>
#include <vtkTextActor.h>
#include <vtkCamera.h>
#include <vtkPLYWriter.h>
#include <vtkPolyDataMapper.h>
#include <vtkActorCollection.h>
#include <vtkPolyVertex.h>
#include <vtkDataSetMapper.h>
#include <vtkLookupTable.h>
#include <vtkUnstructuredGrid.h>
#include <vtkCellArray.h>
#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkAutoInit.h> 
VTK_MODULE_INIT(vtkRenderingFreeType);
VTK_MODULE_INIT(vtkRenderingOpenGL);
VTK_MODULE_INIT(vtkInteractionStyle);
class vtkShowRGB : public QObject
{
    Q_OBJECT
public:
    explicit vtkShowRGB(QObject *parent = nullptr);

signals:

public slots:
    void slt_init();
    void slt_updatedata(pcl::PointCloud<pcl::PointXYZRGB>::Ptr playpointrgb);
    void slt_render();
    void slt_stopandinteract();
private:
//    //rgb point vtk show
//	vtkSmartPointer<vtkRenderer> Rendererrgb;
//	vtkSmartPointer<vtkActor> anActorrgbpointclouds;
//	vtkSmartPointer<vtkLookupTable> lutpointclouds;
//	vtkSmartPointer<vtkActor> anActorrgbtrack;
//	vtkSmartPointer<vtkPoints> pointsrgb;
//	vtkSmartPointer<vtkFloatArray>pointsScalars;
//	vtkSmartPointer<vtkUnstructuredGrid> pointsGrid;
//	vtkSmartPointer<vtkDataSetMapper> pointcloudsMapper;
//	vtkSmartPointer<vtkDataSetMapper> trackMapper;
//	vtkSmartPointer<vtkPolyVertex>polyVertex;
//	vtkSmartPointer<vtkRenderWindow> rgbrenderWindow;

//vtk show
	vtkSmartPointer<vtkActor> m_actor;
	vtkSmartPointer<vtkRenderer> m_renderer;
	vtkSmartPointer<vtkRenderWindow> renderWindow;
	vtkSmartPointer<vtkRenderWindowInteractor> interactor;
};

#endif // VTKSHOWRGB_H
