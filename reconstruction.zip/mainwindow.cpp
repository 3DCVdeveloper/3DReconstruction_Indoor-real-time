#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "Viewer.h"
//using namespace open3d::visualization;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
//    this->showMaximized();
    camerathead = new QThread();
    camera_altra = new astra();
    camera_altra->moveToThread(camerathead);
    odemetrythead = new QThread();
    connect(camera_altra,SIGNAL(sgnl_stop(void)),this,SLOT(slt_stop(void)));
    connect(camera_altra,SIGNAL(sgnl_sendcolorimg(RGB888Pixel*)),this,SLOT(slt_sendcolorimg(RGB888Pixel*)));
    connect(camera_altra,SIGNAL(sgnl_senddepthimg(DepthPixel*)),this,SLOT(slt_senddepthimg(DepthPixel*)));
    connect(camera_altra,SIGNAL(sgl_setintrinsic(double, double, double, double)),this,SLOT(slt_setintrinsic(double, double, double, double)));
    o3d_odemetry = new odemetrytdd();
    connect(camera_altra,SIGNAL(sgnl_sendodemetrycolorimg(cv::Mat)),o3d_odemetry,SLOT(slt_sendcolorimg(cv::Mat)));
    connect(camera_altra,SIGNAL(sgnl_stop(void)),o3d_odemetry,SLOT(slt_stop(void)));
    connect(camera_altra,SIGNAL(sgnl_sendodemetrydepthimg(cv::Mat)),o3d_odemetry,SLOT(slt_senddepthimg(cv::Mat)));
    connect(this,SIGNAL(sgl_setintrinsic(double, double, double, double)),o3d_odemetry,SLOT(slt_setintrinsic(double, double, double, double)));
    connect(o3d_odemetry,SIGNAL(sgnl_manwindowshowpoint(pcl::PointCloud<pcl::PointXYZRGB>::Ptr)),this,SLOT(slt_manwindowshowpoint(pcl::PointCloud<pcl::PointXYZRGB>::Ptr)));
    connect(camera_altra,SIGNAL(sgnl_sendicpcolorimg(RGB888Pixel*)),o3d_odemetry,SLOT(slt_sendicpcolorimg(RGB888Pixel*)));
    connect(camera_altra,SIGNAL(sgnl_sendicpdepthimg(DepthPixel*)),o3d_odemetry,SLOT(slt_sendicpdepthimg(DepthPixel*)));
    o3d_odemetry->moveToThread(odemetrythead);
    odemetrythead->start();
    camerathead->start();

    vtkShowRGBor = new vtkShowRGB();
    connect(o3d_odemetry,SIGNAL(sgnl_initvtk(void)),vtkShowRGBor,SLOT(slt_init(void)));
    connect(o3d_odemetry,SIGNAL(sgnl_rendervtk(void)),vtkShowRGBor,SLOT(slt_render(void)));
    connect(o3d_odemetry,SIGNAL(sgnl_updatepointcloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr)),vtkShowRGBor,SLOT(slt_updatedata(pcl::PointCloud<pcl::PointXYZRGB>::Ptr)));
    connect(camera_altra,SIGNAL(sgnl_stop(void)),vtkShowRGBor,SLOT(slt_stopandinteract(void)));
    vtkshowthread = new QThread();
    vtkShowRGBor->moveToThread(vtkshowthread);
    vtkshowthread->start();
    colorflag =true;
    depthflag =false;
    trajectorflag =false;
    voxelhashingflag =false;
//    shape.push_back(480);
//    shape.push_back(640);
//    shape.push_back(3);
    //colortensorp = new Tensor(shape,core::Dtype::UInt16,core::Device("CPU:0"));
    //480,640,1,core::Dtype::UInt16,core::Device("CPU:0")
//    depthimage = new geometry::Image();
//    depthimage->Prepare(640,480,1,2);
    //imagedata = (uint16_t *)depthimage->GetDataPtr();
    imagedata = new uint16_t[640*480];
//    imagedata = (uint16_t *)std::malloc(640*480);
//    input_color = new geometry::Image();
//    input_color->Prepare(640,480,3,1);
////    colorimagedata = (uint8_t *)input_color->GetDataPtr();
    colorimagedata = new uint8_t[640*480*3];
//    colorimagedata = (uint8_t *)std::malloc(640*480*3);
//    input_color->data_.data();
}

MainWindow::~MainWindow()
{
//    delete imagedata;
//    delete colorimagedata;
    delete ui;
}
void MainWindow::cloudviewONEcloudwithoutnormals(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_source)
{
//	pcl::visualization::PCLVisualizer viewercolortset;
//	viewercolortset.setPosition(700, 500);
//	viewercolortset.setWindowName("contour show");
//	viewercolortset.setCameraPosition(0, 0, 300, 0, 0, -300, 0);

//	viewercolortset.setBackgroundColor(0.05, 0.05, 0.05, 0); // Setting background to a dark grey

//	// Define R,G,B colors for the point cloud
//	pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZRGB> source_cloud_color_handler(cloud_source, 20, 20, 200);
//	//Eigen::Vector4f centroid;
//	//pcl::compute3DCentroid(*cloud_source, centroid); // ŒÆËãÖÊÐÄ
//	//// We add the point cloud to the viewer and pass the color handler
//	viewercolortset.addPointCloud(cloud_source, source_cloud_color_handler, "original_cloud");


//	viewercolortset.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "original_cloud");
//	viewercolortset.addCoordinateSystem(1.0, "cloud", 0);
//	viewercolortset.initCameraParameters();


//	while (!viewercolortset.wasStopped()) { // Display the visualiser until 'q' key is pressed
//		viewercolortset.spinOnce();
//	}
}
void MainWindow::on_OpenCamera_clicked()
{
    //openalstra camera
    camera_altra->Startcamera();
//    auto test=0;

}
void MainWindow::slt_manwindowshowpoint(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow)
{
	//show pcl;
}
void MainWindow::on_OPen3D_clicked()
{
    auto test=0;
    camera_altra->istracking = true;
    //Open3Dtest
//    auto sphere = open3d::geometry::TriangleMesh::CreateSphere(1.0);
//      sphere->ComputeVertexNormals();
//      sphere->PaintUniformColor({0.0, 1.0, 0.0});
//      open3d::visualization::DrawGeometries({sphere});
//    using namespace open3d;
//    using namespace open3d;
//    using core::Tensor;
////    using t::geometry::Image;
////    using t::geometry::PointCloud;
////    using t::geometry::RGBDImage;

////    using t::pipelines::odometry;
////    using t::pipelines::slam;
////    using t::pipelines::registration;
//    std::string device_code ="CPU:0";
//    utility::SetVerbosityLevel(utility::VerbosityLevel::Info);
//    core::Device device(device_code);
//    utility::LogInfo("Using device: {}", device.ToString());
//    std::string color_folder = "/usr/local/Open3D/rgbd_dataset_freiburg1_room/rgb";
//    std::string depth_folder = "/usr/local/Open3D/rgbd_dataset_freiburg1_room/depth";
//    std::vector<std::string> color_filenames, depth_filenames;
//    utility::filesystem::ListFilesInDirectory(color_folder, color_filenames);
//    utility::filesystem::ListFilesInDirectory(depth_folder, depth_filenames);
//    if (color_filenames.size() != depth_filenames.size()) {
//            utility::LogError(
//                    "[DenseSLAM] numbers of color and depth files mismatch. "
//                    "Please provide folders with same number of images.");
//        }
//    std::sort(color_filenames.begin(), color_filenames.end());
//    std::sort(depth_filenames.begin(), depth_filenames.end());
//    size_t n = color_filenames.size();
//    size_t iterations = n;
//    iterations = std::min(n, iterations);
//    // Intrinsics
//    std::string intrinsic_path = "/usr/local/Open3D/rgbd_dataset_freiburg1_room/camera.json";
//    camera::PinholeCameraIntrinsic intrinsic = camera::PinholeCameraIntrinsic(
//                camera::PinholeCameraIntrinsicParameters::PrimeSenseDefault);
//        if (intrinsic_path.empty()) {
//            utility::LogWarning("Using default Primesense intrinsics");
//        } else if (!io::ReadIJsonConvertible(intrinsic_path, intrinsic)) {
//            utility::LogError("Unable to convert json to intrinsics.");
//        }
//        auto focal_length = intrinsic.GetFocalLength();
//        auto principal_point = intrinsic.GetPrincipalPoint();
//        Tensor intrinsic_t = Tensor::Init<double>(
//                {{focal_length.first, 0, principal_point.first},
//                 {0, focal_length.second, principal_point.second},
//                 {0, 0, 1}});
//        // VoxelBlock configurations
//        float voxel_size = 3.f / 512.f;
//        float sdf_trunc = 0.04f;
//        int block_resolution = 16;
//        int block_count = 10000;
//// Odometry configurations
//        float depth_scale = 5000.f;
//        float depth_max = 5.f;
//        float depth_diff = 0.07f;

//        // Initialization
//           Tensor T_frame_to_model =
//                   Tensor::Eye(4, core::Dtype::Float64, core::Device("CPU:0"));

//           t::pipelines::slam::Model model(voxel_size, sdf_trunc, block_resolution,
//                                           block_count, T_frame_to_model, device);

//           // Initialize frame
//           geometry::Image ref_depth = *t::io::CreateImageFromFile(depth_filenames[0]);
//           t::pipelines::slam::Frame input_frame(
//                   ref_depth.GetRows(), ref_depth.GetCols(), intrinsic_t, device);
//           t::pipelines::slam::Frame raycast_frame(
//                   ref_depth.GetRows(), ref_depth.GetCols(), intrinsic_t, device);

//           // Iterate over frames
//               for (size_t i = 0; i < iterations; ++i) {
//                   utility::LogInfo("Processing {}/{}...", i, iterations);
//                   // Load image into frame 480,640 1 480 640 3
//                   geometry::Image input_depth = *t::io::CreateImageFromFile(depth_filenames[i]);
//                   geometry::Image input_color = *t::io::CreateImageFromFile(color_filenames[i]);
//                   input_frame.SetDataFromImage("depth", input_depth);
//                   input_frame.SetDataFromImage("color", input_color);

//                   bool tracking_success = true;
//                   if (i > 0) {
//                       auto result =
//                               model.TrackFrameToModel(input_frame, raycast_frame,
//                                                       depth_scale, depth_max, depth_diff);

//                       core::Tensor translation =
//                               result.transformation_.Slice(0, 0, 3).Slice(1, 3, 4);
//                       double translation_norm = std::sqrt(
//                               (translation * translation).Sum({0, 1}).Item<double>());

//                       // TODO(wei): more systematical failure check.
//                       // If the overlap is too small or translation is too high between
//                       // two consecutive frames, it is likely that the tracking failed.
//                       if (result.fitness_ >= 0.1 && translation_norm < 0.15) {
//                           T_frame_to_model =
//                                   T_frame_to_model.Matmul(result.transformation_);
//                       } else {  // Don't update
//                           tracking_success = false;
//                           utility::LogWarning(
//                                   "Tracking failed for frame {}, fitness: {:.3f}, "
//                                   "translation: {:.3f}. Using previous frame's "
//                                   "pose.",
//                                   i, result.fitness_, translation_norm);
//                       }
//                   }

//                   // Integrate
//                   model.UpdateFramePose(i, T_frame_to_model);
//                   if (tracking_success) {
//                       model.Integrate(input_frame, depth_scale, depth_max);
//                   }
//                   model.SynthesizeModelFrame(raycast_frame, depth_scale, 0.1, depth_max,
//                                              false);
//               }

////               if (utility::ProgramOptionExists(argc, argv, "--pointcloud"))
//               {
////                   std::string filename = utility::GetProgramOptionAsString(
////                           argc, argv, "--pointcloud",
////                           "pcd_" + device.ToString() + ".ply");
////                   auto pcd = model.ExtractPointCloud(-1);
////                   auto pcd_legacy =
////                           std::make_shared<open3d::geometry::PointCloud>(pcd.ToLegacy());
////                   open3d::io::WritePointCloud(filename, *pcd_legacy);
//               }

////               if (utility::ProgramOptionExists(argc, argv, "--mesh"))
//               {
//                   std::string filename =  "mesh_" + device.ToString() + ".ply";
//                   auto mesh = model.ExtractTriangleMesh(-1);
//                   auto mesh_legacy = std::make_shared<open3d::geometry::TriangleMesh>(
//                           mesh.ToLegacy());
//                   open3d::io::WriteTriangleMesh(filename, *mesh_legacy);
//               }

////std::string dataset_path = "/usr/local/Open3D/rgbd_dataset_freiburg1_room";
////std::string intrinsic_path = "/usr/local/Open3D/rgbd_dataset_freiburg1_room/camera.json";
////std::string device_code ="CUDA:0";
////char* argv[]="DenseSLAMGUI [/usr/local/Open3D/rgbd_dataset_freiburg1_room] --voxel_size [=0.0058 (m)] --device [CUDA:0] --intrinsic_path [/usr/local/Open3D/rgbd_dataset_freiburg1_room/camera.json]";
////    auto& app = gui::Application::GetInstance();
////        app.Initialize();
////        auto mono =
////                app.AddFont(gui::FontDescription(gui::FontDescription::MONOSPACE));
////        app.AddWindow(std::make_shared<ReconstructionWindow>(
////                dataset_path, intrinsic_path, device_code, mono));
////        app.Run();

}

void MainWindow::on_close_camera_clicked()
{
    camera_altra->Stopcamera();
//    auto test=0;
}
void MainWindow::slt_sendcolorimg(RGB888Pixel* pcolorsend)
{
    int width=640;
    int height=480;

    if(colorflag)
    {
        RGB888Pixel *pcolorshow = new RGB888Pixel[640*480];
        std::copy(pcolorsend,pcolorsend+640*480,pcolorshow);


        for (int j = 0; j < height; ++j)

        {

            for (int i = 0; i < width; ++i)

            {

               // leftImg.setPixelColor(i, j, QColor(pcolorshow[j * width + i].r, pcolorshow[j * width + i].g, pcolorshow[j * width + i].b));
                colorimagedata[j * width*3 + i*3]=pcolorshow[j * width + i].r;
                colorimagedata[j* width*3 + i*3+1]=pcolorshow[j * width + i].g;
                colorimagedata[(j) * width*3 + i*3+2]=pcolorshow[j * width + i].b;
//                input_color->At(j,i)[0]=pcolorshow[j * width + i].r;
//                input_color->At(j,i)[0]=pcolorshow[j * width + i].g;
//                input_color->At(j,i)[0]=pcolorshow[j * width + i].b;
//                colortensor.push_back(input_color->At(j,i)[0].AsRvalue());
//                colortensor.push_back(pcolorshow[j * width + i].g);
//                colortensor.push_back(pcolorshow[j * width + i].b);
              //  rightImg.setPixelColor(i, height - j - 1, QColor(right_img[j * width + i], right_img[j * width + i], right_img[j * width + i]));

            }

        }
        //open3d::core::Tensor<uint8_t> colortensorp(colortensor,shape,core::Dtype::UInt16,core::Device("CPU:0"));

        QImage leftImg((const unsigned char*)colorimagedata,width, height, QImage::Format_RGB888);
        leftImg.scaled(ui->color_img->size(), Qt::KeepAspectRatio);

        ui->color_img->setScaledContents(true);
        ui->color_img->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
        ui->color_img->setPixmap(QPixmap::fromImage(leftImg));
        delete pcolorshow;
    }
}
void MainWindow::slt_senddepthimg(DepthPixel* pdepthsend)
{
    uint16_t max_depth = MAX_DISTANCE;

    uint16_t min_depth = MIN_DISTANCE;
    if(depthflag)
    {
        DepthPixel * depthshow=new DepthPixel[640*480];

        std::copy(pdepthsend,pdepthsend+640*480,depthshow);
        std::vector<uint16_t> imginputcvct;


        int width=640;
        int height=480;
        QImage leftImg((const unsigned char*)depthshow,width, height, QImage::Format_RGB16);


        for (int j = 0; j < height; ++j)

        {

            for (int i = 0; i < width; ++i)

            {
//                if (depthshow[j * width + i] <= 0 || depthshow[j * width + i] < min_depth || depthshow[j * width + i] > max_depth)

//                    continue;
                imagedata[j * width + i] = (uint16_t)depthshow[j * width + i]/255;
//                depthimage->At(j,i)= (uint16_t)depthshow[j * width + i];
                //imginputcvct.push_back(depth);
                auto depttest=0;

    //            leftImg.set

               // leftImg.setPixelColor(width-1-i, j, QColor(depthshow[j * width + i], depthshow[j * width + i], depthshow[j * width + i]));

            }

        }
        //Tensor imginputc(imginputcvct,core::Device("CUDA:0"));//,open3d::core::UInt16,core::Device("CUDA:0"));

//        auto test = depthimage->GetDtype();

        leftImg.scaled(ui->depth_img->size(), Qt::KeepAspectRatio);

        ui->depth_img->setScaledContents(true);
        ui->depth_img->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
        ui->depth_img->setPixmap(QPixmap::fromImage(leftImg));
        delete depthshow;
    }
}

void MainWindow::slt_setintrinsic(double fx, double fy, double cx, double cy)
{
    emit sgl_setintrinsic(fx,fy,cx,cy);
}
void MainWindow::slt_stop()
{

}

void MainWindow::on_colorflagshow_clicked()
{
    if(!colorflag)
    {
        colorflag =true;
    }
    else
    {
        colorflag =false;
    }
}

void MainWindow::on_depthshowflag_clicked()
{
    if(!depthflag)
    {
        depthflag =true;
    }
    else
    {
        depthflag =false;
    }
}
