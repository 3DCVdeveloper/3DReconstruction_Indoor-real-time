#include "astra.h"



astra::astra(QObject *parent)

    : QObject(parent)

{

    colorimg =NULL;
    istracking = false;

}



astra::~astra()

{

}

void astra::getCameraParams(openni::Device& Device, xIntrinsic_Params& IrParam)

{

    OBCameraParams cameraParam;

    int dataSize = sizeof(cameraParam);

    memset(&cameraParam, 0, sizeof(cameraParam));

    openni::Status rc = Device.getProperty(14, (uint8_t*)&cameraParam, &dataSize);

    if (rc != openni::STATUS_OK)

    {

//        std::cout << "Error:" << openni::OpenNI::getExtendedError() << std::endl;

        return;

    }

    IrParam.f_x = cameraParam.l_intr_p[0]; //u轴上的归一化焦距

    IrParam.f_y = cameraParam.l_intr_p[1]; //v轴上的归一化焦距

    IrParam.c_x = cameraParam.l_intr_p[2]; //主点x坐标

    IrParam.c_y = cameraParam.l_intr_p[3]; //主点y坐标

    emit sgl_setintrinsic(IrParam.f_x,IrParam.f_y,IrParam.c_x,IrParam.c_y);

//    std::cout << "IrParam.f_x = " << IrParam.f_x << std::endl;

//    std::cout << "IrParam.f_y = " << IrParam.f_y << std::endl;

//    std::cout << "IrParam.c_x = " << IrParam.c_x << std::endl;

//    std::cout << "IrParam.c_y = " << IrParam.c_y << std::endl;

}

void astra::convertDepthToPointCloud(const uint16_t* pDepth, int width, int height, const char* ply_filename)

{

    if (NULL == pDepth)

    {

//        printf("depth frame is NULL!");

        return;

    }

    //将深度数据转换为点云数据,并将点云数据保存到文件中

    //FILE* fp;



    //int res = fopen_s(&fp, ply_filename, "w");

    //fp = fopen(ply_filename, "w");



    int valid_count = 0;

    uint16_t max_depth = MAX_DISTANCE;

    uint16_t min_depth = MIN_DISTANCE;



    //统计有效的数据条数

    int img_size = width * height;

    for (int v = 0; v < height; ++v)

    {

        for (int u = 0; u < width; ++u)

        {

            uint16_t depth = pDepth[v * width + u];

            if (depth <= 0 || depth < min_depth || depth > max_depth)

                continue;



            valid_count += 1;

        }

    }

    //pointload = pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>);

    ////ply点云文件的头

    //fprintf(fp, "ply\n");

    //fprintf(fp, "format ascii 1.0\n");

    //fprintf(fp, "element vertex %d\n", valid_count);

    //fprintf(fp, "property float x\n");

    //fprintf(fp, "property float y\n");

    //fprintf(fp, "property float z\n");

    //fprintf(fp, "property uchar red\n");

    //fprintf(fp, "property uchar green\n");

    //fprintf(fp, "property uchar blue\n");

    //fprintf(fp, "end_header\n");



    float world_x, world_y, world_z;

    for (int v = 0; v < height; ++v)

    {

        for (int u = 0; u < width; ++u)

        {

            uint16_t depth = pDepth[v * width + u];

            if (depth <= 0 || depth < min_depth || depth > max_depth)

                continue;



            //分辨率缩放，这里假设标定时的分辨率分RESOULTION_X，RESOULTION_Y

            float fdx = g_IntrinsicParam.f_x * ((float)(width) / RESOULTION_X);

            float fdy = g_IntrinsicParam.f_y * ((float)(height) / RESOULTION_Y);

            float u0 = g_IntrinsicParam.c_x * ((float)(width) / RESOULTION_X);

            float v0 = g_IntrinsicParam.c_y * ((float)(height) / RESOULTION_Y);



            float tx = (u - u0) / fdx;

            float ty = (v - v0) / fdy;



            world_x = depth * tx;

            world_y = depth * ty;

            world_z = depth;

//            pcl::PointXYZ point;

//            point.x = world_x;

//            point.y = -world_y;

//            point.z = -world_z;

//            pointload->points.push_back(point);

            //fprintf(fp, "%f %f %f 255 255 255\n", world_x, world_y, world_z);

        }

    }

    QString current_date_time = QDateTime::currentDateTime().toString("yyyy-MM-dd_hh.mm.ss.zzz");

//    std::cout << current_date_time.toStdString() << endl;

    //sgnl_getPointCloud(pointload);

    //fclose(fp);

}
//void astra::run()
//{
//    int changedIndex;
//    openni::Status rc = openni::OpenNI::waitForAnyStream(m_streams, 2, &changedIndex);
//    if (rc != openni::STATUS_OK)
//    {
//        printf("Wait failed\n");
//        return;
//    }

//    switch (changedIndex)
//    {
//    case 0:
//        depth.readFrame(&m_depthFrame); break;
//    case 1:
//        color.readFrame(&m_colorFrame); break;
//    default:
//        printf("Error in wait\n");
//    }

//    msleep(10);
//}
void astra::analyzecolorFrame(const VideoFrameRef& frame)
{
    RGB888Pixel* pcolor;
    g_colorimageCount++;
    if (g_colorimageCount % 30 == 0)

    {

        g_colorimageCount = 0;
        int middleIndex = (frame.getHeight() + 1) * frame.getWidth() / 2;
        cv::Mat tmp, tmp2;
        cv::Mat grayRef;
        switch (frame.getVideoMode().getPixelFormat())

        {

        case PIXEL_FORMAT_RGB888:

            tmp = cv::Mat(frame.getHeight(), frame.getWidth(), CV_8UC3, (char*)frame.getData());
            cv::flip(tmp, tmp2, 1);

            cv::cvtColor(tmp2, tmp2, CV_RGB2GRAY);
            tmp2.convertTo(grayRef, CV_32FC1, 1.0f / 255.0f);

            pcolor = (RGB888Pixel*)frame.getData();

    //        int Hsum=frame.getHeight();
    //        int Wsum = frame.getWidth();
    //        colorimg = new unsigned char[Wsum*Hsum*3];
    //        for(int i=0;i<Hsum;i++)
    //        {
    //            for(int j=0;j<Wsum;j++)
    //            {
    //                for(int k=0;k<3;)
    //                colorimg[i*Wsum+j+0]
    //            }
    //        }
            emit sgnl_sendcolorimg(pcolor);
//            if(istracking)
            {
                emit sgnl_sendicpcolorimg(pcolor);
            }
//            emit sgnl_sendodemetrycolorimg(grayRef);
//            printf("[%08llu] %8d\n", (long long)frame.getTimestamp(),

                //pcolor[middleIndex]);



            //将深度数据转换为点云并保存成ply文件，每帧深度数据对应一个ply文件

           // convertDepthToPointCloud(pDepth, frame.getWidth(), frame.getHeight(), plyFileName);

            break;

        default:

            printf("Unknown format\n");

        }
    }

}
void astra::analyzeFrame(const VideoFrameRef& frame)

{

    DepthPixel* pDepth;



    //构造点云文件名

    char plyFileName[256] = "";

    g_imageCount++;

    /*if (MAX_FRAME_COUNT < g_imageCount)

    {

        return;

    }*/

    if (g_imageCount % 30 == 0)

    {

        g_imageCount = 0;

        cv::Mat grayRef;
        cv::Mat depthRef;
        cv::Mat tmp, tmp2;
//        std::stringstream filename;

//        filename << "pointcloud_";

//        filename << g_imageCount;

//        filename << ".ply";

//        filename >> plyFileName;



        int middleIndex = (frame.getHeight() + 1) * frame.getWidth() / 2;



        switch (frame.getVideoMode().getPixelFormat())

        {

        case PIXEL_FORMAT_DEPTH_1_MM:

            tmp = cv::Mat(frame.getHeight(), frame.getWidth(), CV_16UC1, (char*)frame.getData());
            cv::flip(tmp, tmp2, 1);
            tmp2.convertTo(depthRef, CV_32FC1, (1.0 / 1000.0));
            pDepth = (DepthPixel*)frame.getData();
            emit sgnl_senddepthimg(pDepth);
//            if(istracking)
            {
                emit sgnl_sendicpdepthimg(pDepth);
            }
//            emit sgnl_sendodemetrydepthimg(depthRef);

//            printf("[%08llu] %8d\n", (long long)frame.getTimestamp(),

                //pDepth[middleIndex]);



            //将深度数据转换为点云并保存成ply文件，每帧深度数据对应一个ply文件

//            convertDepthToPointCloud(pDepth, frame.getWidth(), frame.getHeight(), plyFileName);

            break;

        default:

            printf("Unknown format\n");

        }

    }

}

int astra::Startcamera()

{

    g_imageCount = 0;

    Status rc = OpenNI::initialize();

    if (rc != STATUS_OK)

    {

        printf("Initialize failed\n%s\n", OpenNI::getExtendedError());

        return 1;

    }



    //open deivce



    rc = device.open(ANY_DEVICE);

    if (rc != STATUS_OK)

    {

        printf("Couldn't open device\n%s\n", OpenNI::getExtendedError());

        return 2;

    }


    //create depth stream

    if (device.getSensorInfo(SENSOR_DEPTH) != NULL)

    {



        rc = depth.create(device, SENSOR_DEPTH);

        if (rc != STATUS_OK)

        {

            printf("Couldn't create depth stream\n%s\n", OpenNI::getExtendedError());

        }

    }
    openni::VideoMode depthMode;

    depthMode.setResolution(640, 480);

    depthMode.setPixelFormat(openni::PIXEL_FORMAT_DEPTH_1_MM);

    depthMode.setFps(30);

    depth.setVideoMode(depthMode);


    //start depth stream

    rc = depth.start();

    if (rc != STATUS_OK)

    {

        printf("Couldn't start the depth stream\n%s\n", OpenNI::getExtendedError());

    }

    rc = color.create(device, openni::SENSOR_COLOR);
    if (rc == openni::STATUS_OK)
    {
        openni::VideoMode colorMode;

        colorMode.setResolution(640, 480);

        colorMode.setPixelFormat(openni::PIXEL_FORMAT_RGB888);

        colorMode.setFps(30);

        color.setVideoMode(colorMode);
        rc = color.start();
        if (rc != openni::STATUS_OK)
        {
            printf("SimpleViewer: Couldn't start color stream:\n%s\n", openni::OpenNI::getExtendedError());
            color.destroy();
        }
    }
    else
    {
        printf("SimpleViewer: Couldn't find color stream:\n%s\n", openni::OpenNI::getExtendedError());
    }

    openni::VideoMode depthVideoMode;
    openni::VideoMode colorVideoMode;
    device.setDepthColorSyncEnabled(true);
    device.setImageRegistrationMode(openni::IMAGE_REGISTRATION_DEPTH_TO_COLOR);
    if (depth.isValid() && color.isValid())
    {
        depthVideoMode = depth.getVideoMode();
        colorVideoMode = color.getVideoMode();

        int depthWidth = depthVideoMode.getResolutionX();
        int depthHeight = depthVideoMode.getResolutionY();
        int colorWidth = colorVideoMode.getResolutionX();
        int colorHeight = colorVideoMode.getResolutionY();

        if (depthWidth == colorWidth &&
            depthHeight == colorHeight)
        {
            m_width = depthWidth;
            m_height = depthHeight;
        }
        else
        {
            printf("Error - expect color and depth to be in same resolution: D: %dx%d, C: %dx%d\n",
                depthWidth, depthHeight,
                colorWidth, colorHeight);
            return openni::STATUS_ERROR;
        }
    }

    m_streams = new openni::VideoStream*[2];
    m_streams[0] = &depth;
    m_streams[1] = &color;

    std::function<void(VideoFrameRef)> fun = std::bind(&astra::analyzeFrame, this, std::placeholders::_1);

    depthPrinter.installTrackingMsgFilter(fun);



    // Register frame listener

    depth.addNewFrameListener(&depthPrinter);

    std::function<void(VideoFrameRef)> funcolor = std::bind(&astra::analyzecolorFrame, this, std::placeholders::_1);

    colorPrinter.installTrackingMsgFilter(funcolor);



    // Register frame listener

    color.addNewFrameListener(&colorPrinter);


    //get intrinsic parameter from device

    getCameraParams(device, g_IntrinsicParam);



    // Wait while we're getting frames through the printer

    //while (MAX_FRAME_COUNT > g_imageCount)

    //{

    //	Sleep(100);

    //}

    return 0;



}

void astra::Stopcamera()

{

    depth.removeNewFrameListener(&depthPrinter);



    //stop depth stream

    depth.stop();



    //destroy depth stream

    depth.destroy();



    //close device

//    device.close();

    color.removeNewFrameListener(&colorPrinter);



    //stop depth stream

    color.stop();



    //destroy depth stream

    color.destroy();



    //close device

    device.close();

    //shutdown OpenNI

    OpenNI::shutdown();
    emit sgnl_stop();

}

