#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <string>
#include <iostream>
#include "astra.h"
//#include "open3d/Open3D.h"
//#include <OpenNI.h>
#include <QThread>
#include <QMutex>
//#include "reconstructionwindow.h"
//#include "voxcelhashing.h"
#include "odemetryd.h"
#include "vtkshowrgb.h"
//#include "Viewer.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
signals:
    void sgl_setintrinsic(double fx, double fy, double cx, double cy);
private slots:
    void on_OpenCamera_clicked();

    void on_OPen3D_clicked();

    void on_close_camera_clicked();
//    void slt_getimg();
    void slt_sendcolorimg(RGB888Pixel* pcolorsend);
    void slt_senddepthimg(DepthPixel* pdepthsend);
//    void on_colorflagshow_clicked();

//    void on_depthshowflag_clicked();
    void slt_setintrinsic(double fx, double fy, double cx, double cy);
    void slt_stop();
    void on_colorflagshow_clicked();

    void on_depthshowflag_clicked();
    void slt_manwindowshowpoint(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow);


private:
    Ui::MainWindow *ui;
    QThread *camerathead;
    QThread *odemetrythead;
    QThread *vtkshowthread;
    astra *camera_altra;
    odemetrytdd *o3d_odemetry;
    vtkShowRGB *vtkShowRGBor;
    bool colorflag;
    bool depthflag;
    bool trajectorflag;
    bool voxelhashingflag;
//    geometry::Image *depthimage;
    uint16_t *imagedata;
    uint8_t *colorimagedata;
//    geometry::Image *input_color;
//    open3d::core::SizeVector shape;
    std::vector<uint8_t> colortensor;
    void cloudviewONEcloudwithoutnormals(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_source);

};

#endif // MAINWINDOW_H
