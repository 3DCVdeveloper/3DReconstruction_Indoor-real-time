#include "opencvreg.h"

opencvreg::opencvreg(QObject *parent) : QObject(parent)
{
    / 构建提取器，默认两者都为sift
 // 构建sift, surf之前要初始化nonfree模块
 cv::initModule_nonfree();
 _detector = cv::FeatureDetector::create( "GridSIFT" );
 _descriptor = cv::DescriptorExtractor::create( "SIFT" );
}
void opencvreg::slt_setintrinsic(double fx, double fy, double cx, double cy)
{
    Cpara.cx = cx;
    Cpara.cy = cy;
    Cpara.fx = fx;
    Cpara.fy = fy;
    Cpara.scale = 1000.0;
}
void opencvreg::cvregistration(cv::Mat pcolorref,cv::Mat pcolorcur)
{
    vector< cv::KeyPoint > kp1, kp2; //关键点
    _detector->detect( pcolorref, kp1 );  //提取关键点
    _detector->detect( pcolorcur, kp2 );
    cout<<"Key points of two images: "<<kp1.size()<<", "<<kp2.size()<<endl;
    cv::Mat desp1, desp2;
    _descriptor->compute( pcolorref, kp1, desp1 );
    _descriptor->compute( pcolorcur, kp2, desp2 );
    // 匹配描述子
    vector< cv::DMatch > matches; 
    cv::FlannBasedMatcher matcher;
    matcher.match( desp1, desp2, matches );
    cout<<"Find total "<<matches.size()<<" matches."<<endl;

    // 筛选匹配，把距离太大的去掉
     // 这里使用的准则是去掉大于四倍最小距离的匹配
    vector< cv::DMatch > goodMatches;
    double minDis = 9999;
    for ( size_t i=0; i<matches.size(); i++ )
    {
         if ( matches[i].distance < minDis )
        {
            minDis = matches[i].distance;
        }
    }

     for ( size_t i=0; i<matches.size(); i++ )
    {
         if (matches[i].distance < 4*minDis)
            {
                goodMatches.push_back( matches[i] );
            } 
    }

    for (size_t i=0; i<goodMatches.size(); i++)
    {
         // query 是第一个, train 是第二个
        cv::Point2f p = kp1[goodMatches[i].queryIdx].pt;
        // 获取d是要小心！x是向右的，y是向下的，所以y才是行，x是列！
        ushort d = depth1.ptr<ushort>( int(p.y) )[ int(p.x) ];
        if (d == 0)
             continue;
        pts_img.push_back( cv::Point2f( kp2[goodMatches[i].trainIdx].pt ) );

        // 将(u,v,d)转成(x,y,z)
         cv::Point3f pt ( p.x, p.y, d );
        cv::Point3f pd = point2dTo3d( pt, C );
        pts_obj.push_back( pd );
         }

        double camera_matrix_data[3][3] = {
            {C.fx, 0, C.cx},
            {0, C.fy, C.cy},
            {0, 0, 1}
         };
         // 构建相机矩阵
        cv::Mat cameraMatrix( 3, 3, CV_64F, camera_matrix_data );
        cv::Mat rvec, tvec, inliers;
        // 求解pnp
        cv::solvePnPRansac( pts_obj, pts_img, cameraMatrix, cv::Mat(), rvec, tvec, false, 100, 1.0, 100, inliers );

        cout<<"inliers: "<<inliers.rows<<endl;
        cout<<"R="<<rvec<<endl;
        cout<<"t="<<tvec<<endl;
}