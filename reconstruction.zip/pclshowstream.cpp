#include "pclshowstream.h"

pclshowstream::pclshowstream()
{

}
void pclshowstream::run()
{
//    while (!viewercolortset.wasStopped())
//    { // Display the visualiser until 'q' key is pressed
//        viewercolortset.spinOnce();
////        this->sleep(100);
//    }
}
void pclshowstream::initshowstream(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow)
{
//    viewer.setWindowName("point viewer");
//    viewer.
//    viewercolortset.setPosition(700, 500);
//    viewercolortset.setWindowName("point viewer");
////    viewercolortset.setCameraPosition(0, 0, 0, 0, 0, 0, 0, 0, -1);
//    viewercolortset.setBackgroundColor(1,1,1);
//    viewercolortset.addPointCloud<pcl::PointXYZRGB> (pointshow, "sample cloud");
//    viewercolortset.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "sample cloud");
//    viewercolortset.addCoordinateSystem(1.0,0,3,0 ,"cloud", 0);
//    viewercolortset.initCameraParameters ();
}
void pclshowstream::slt_setCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow)
{
//     viewercolortset.updatePointCloud<pcl::PointXYZRGB>(pointshow,"sample cloud");
//    viewer.showCloud(pointshow);
}
