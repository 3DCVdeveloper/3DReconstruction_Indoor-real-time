#ifndef PCLSHOWSTREAM_H
#define PCLSHOWSTREAM_H

#include <QObject>
#include <QThread>
#include <pcl/io/pcd_io.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/gicp.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/filters/fast_bilateral.h>
#include <pcl/filters/bilateral.h>
#include <pcl/common/common.h>

#include <pcl/kdtree/flann.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/search/flann_search.h>
#include <pcl/search/kdtree.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/filters/bilateral.h>
class pclshowstream : public QThread
{
    Q_OBJECT
public:
    pclshowstream();
    void initshowstream(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow);
signals:
public slots:
    void slt_setCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow);
protected:
    virtual void run();
private:
//    pcl::visualization::PCLVisualizer viewercolortset;
//    pcl::visualization::CloudViewer viewer;
    //pcl::PointCloud<pcl::PointXYZRGB>::Ptr pointshow;
};

#endif // PCLSHOWSTREAM_H
