#pragma once



#include <QObject>

#include "OpenNI.h"

#include <QMutex>

#include <QDateTime>
#include <QMap>
#include <iostream>
#include <QThread>
//#include "OniSampleUtilities.h"
//#include "pcl/point_cloud.h"
//#include <pcl/io/io.h>
//#include <pcl/
#include <pcl/point_cloud.h>
#include <pcl/io/io.h>
#include "odemetryd.h"
#include <opencv2/core/core.hpp>
#include <opencv2/core.hpp>
#define SAMPLE_READ_WAIT_TIMEOUT 2000 //2000ms

#define MIN_DISTANCE 900  //单位毫米

#define MAX_DISTANCE 4000 //单位毫米

#define RESOULTION_X 640.0  //标定时的分辨率

#define RESOULTION_Y 480.0  //标定时的分辨率

#define MAX_DEPTH 4000

#define MAX_FRAME_COUNT 50

using namespace openni;
using namespace std;
//typedef struct OBCameraParams

//{

//    float l_intr_p[4];//[fx,fy,cx,cy]

//    float r_intr_p[4];//[fx,fy,cx,cy]

//    float r2l_r[9];//[r00,r01,r02;r10,r11,r12;r20,r21,r22]

//    float r2l_t[3];//[t1,t2,t3]

//    float l_k[5];//[k1,k2,p1,p2,k3]

//    float r_k[5];

//    //int is_mirror;

//}OBCameraParams;

typedef struct xnIntrinsic_Params

{

    xnIntrinsic_Params() :

        c_x(320.0), c_y(240.0), f_x(480.0), f_y(480.0)

    {}



    xnIntrinsic_Params(float c_x_, float c_y_, float f_x_, float f_y_) :

        c_x(c_x_), c_y(c_y_), f_x(f_x_), f_y(f_y_)

    {}



    float c_x; //u轴上的归一化焦距

    float c_y; //v轴上的归一化焦距

    float f_x; //主点x坐标

    float f_y; //主点y坐标

}xIntrinsic_Params;





class PrintCallback : public VideoStream::NewFrameListener

{

public:

    void onNewFrame(VideoStream& stream)

    {

        stream.readFrame(&m_frame);



        m_astracllback(m_frame);

    }

    void installTrackingMsgFilter(std::function<void(VideoFrameRef)> astracallback)

    {

        if (astracallback != nullptr)

        {

            m_astracllback = astracallback;

        }

    }

private:

    std::function<void(VideoFrameRef)> m_astracllback;

    VideoFrameRef m_frame;

};

class astra : public QObject

{

    Q_OBJECT



public:

    astra(QObject *parent = nullptr);

    ~astra();

    int Startcamera();

    void Stopcamera();
    bool istracking;

private:

    PrintCallback depthPrinter;
    PrintCallback colorPrinter;

    void getCameraParams(openni::Device& Device, xIntrinsic_Params& IrParam);

    void convertDepthToPointCloud(const uint16_t* pDepth, int width, int height, const char* ply_filename);

    void analyzeFrame(const VideoFrameRef& frame);
    void analyzecolorFrame(const VideoFrameRef& frame);

    int g_imageCount;
    int g_colorimageCount;

    VideoStream depth;
    VideoStream color;
    Device device;

    openni::VideoFrameRef		m_depthFrame;
    openni::VideoFrameRef		m_colorFrame;
    openni::VideoStream**		m_streams;
    xIntrinsic_Params g_IntrinsicParam; //存储相机内参的全局变量
    int			m_width;
    int			m_height;
    unsigned char * colorimg;
    DepthPixel* pDepthsend;
    RGB888Pixel* pcolorsend;


protected:
   // void run() override;


signals:
    void sgnl_sendcolorimg(RGB888Pixel* pcolorsend);
    void sgnl_sendodemetrycolorimg(cv::Mat pcolorsend);
    void sgnl_sendicpcolorimg(RGB888Pixel* pcolorsend);
    void sgnl_senddepthimg(DepthPixel* pdepthsend);
    void sgnl_sendodemetrydepthimg(cv::Mat depthsend);
    void sgnl_sendicpdepthimg(DepthPixel* pdepthsend);
    void sgl_setintrinsic(double fx, double fy, double cx, double cy);
    void sgnl_stop();
    //void sgnl_getPointCloud(pcl::PointCloud<pcl::PointXYZ>::Ptr pointcloudrt);

};

