#ifndef OPENCVREG_H
#define OPENCVREG_H
#include <fstream>
#include <vector>
using namespace std;
#include <QObject>
// OpenCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
 // OpenCV 特征检测模块
 #include <opencv2/features2d/features2d.hpp>
 #include <opencv2/nonfree/nonfree.hpp>
 #include <opencv2/calib3d/calib3d.hpp>
 //PCL
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
struct CAMERA_INTRINSIC_PARAMETERS 
 { 
     double cx, cy, fx, fy, scale;
 };
class opencvreg : public QObject
{
    Q_OBJECT
public:
    explicit opencvreg(QObject *parent = nullptr);

signals:


public slots:
    void cvregistration(cv::Mat pcolorref,cv::Mat pcolorcur);
private:
    cv::Ptr<cv::FeatureDetector> _detector;
     cv::Ptr<cv::DescriptorExtractor> _descriptor;
     CAMERA_INTRINSIC_PARAMETERS Cpara;
};

#endif // OPENCVREG_H